# Rank-four oriented-matroid face incidence

This task asks for an exact face-incidence certificate of an integer point configuration in rank-four oriented-matroid geometry. The mathematical objects are chirotope signs, supporting covectors, merged non-simplicial faces, boundary vertex sets, and incidence counts over vertex triples.

The challenge is exact discrete geometry: coplanar support sets must be merged, interior points must be excluded, and all hashes must be derived from canonical face-lattice records.
