"""Exact checks for a rank-four oriented-matroid face-incidence certificate.

The reference profile is derived from integer orientation determinants in R^4.
It merges all affine-independent four-point supports that produce the same
complete coplanar face, excludes interior points, sorts facet incidence rows,
and audits the resulting face lattice through facet and triple-support hashes.
"""

import itertools
import random
import subprocess
from pathlib import Path

import pytest

from baselines import MODES

HASH_MOD = 1_000_000_007
HASH_BASE = 1_000_003


def determinant(matrix):
    if len(matrix) == 1:
        return matrix[0][0]
    return sum((-1) ** col * matrix[0][col] * determinant([row[:col] + row[col + 1:] for row in matrix[1:]]) for col in range(len(matrix)))


def orient(a, b, c, d, q):
    return determinant([[p[j] - a[j] for j in range(4)] for p in (b, c, d, q)])


def reference_facet_profile(points):
    facets = set()
    for i, j, k, m in itertools.combinations(range(len(points)), 4):
        values = [orient(points[i], points[j], points[k], points[m], q) for q in points]
        if not (any(v > 0 for v in values) and any(v < 0 for v in values)) and any(values):
            facets.add(tuple(q for q, value in enumerate(values) if value == 0))
    hull = sorted({q for facet in facets for q in facet})
    hull_line = "HULL " + str(len(hull))
    if hull:
        hull_line += " " + " ".join(str(q + 1) for q in hull)
    lines = [hull_line, f"FACETS {len(facets)}"]
    lines.extend("FACET " + str(len(facet)) + " " + " ".join(str(q + 1) for q in facet) for facet in sorted(facets))
    facet_hash = 17
    for facet in sorted(facets):
        for value in (len(facet), *(q + 1 for q in facet)):
            facet_hash = (facet_hash * HASH_BASE + value) % HASH_MOD
    support_hash = 31
    for triple in itertools.combinations(hull, 3):
        count = sum(all(vertex in facet for vertex in triple) for facet in facets)
        for value in (*(q + 1 for q in triple), count):
            support_hash = (support_hash * HASH_BASE + value) % HASH_MOD
    lines.append(f"FACET_HASH {facet_hash}")
    lines.append(f"TRIPLE_SUPPORT_HASH {support_hash}")
    return "\n".join(lines) + "\n"


def cases():
    rng = random.Random(0x4D)
    out = []
    for index in range(72):
        vectors = []
        while len(vectors) < 3 + index % 4:
            v = tuple(rng.randrange(2, 80) * (1 if rng.randrange(2) else -1) for _ in range(4))
            if v not in vectors and tuple(-x for x in v) not in vectors:
                vectors.append(v)
        points = [v for v in vectors for v in (v, tuple(-x for x in v))]
        points.extend(tuple(rng.randrange(-8, 9) for _ in range(4)) for _ in range(index % 3))
        rng.shuffle(points)
        if len(points) >= 5 and len(reference_facet_profile(points).splitlines()) >= 3:
            out.append(tuple(points))
    return out


CASES = cases()
BIN = None


@pytest.fixture(scope="session", autouse=True)
def prepare_four_dimensional_profile():
    global BIN
    subprocess.run(["make", "clean", "all"], cwd="/app", check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    BIN = Path("/app/bin/hull4_facet_profile")
    assert BIN.is_file()


def execute(points):
    data = str(len(points)) + "\n" + "\n".join(" ".join(map(str, p)) for p in points) + "\n"
    result = subprocess.run([str(BIN)], input=data, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert result.returncode == 0, result.stderr
    assert result.stderr == ""
    assert result.stdout == reference_facet_profile(points)


@pytest.mark.parametrize("index", range(len(CASES)))
def test_exact_rank_four_face_case(index):
    """Verify rank-four support orientation, facet merging, and boundary membership."""
    execute(CASES[index])


def test_relabeling_metamorphism():
    """Relabeling points changes only the one-based IDs in the canonical signature."""
    points = list(CASES[12])
    points = points[::2] + points[1::2]
    execute(points)


def test_wrong_semantics_are_separated():
    """Interior points and non-simplicial support families defeat common shortcuts."""
    assert len(CASES) >= 60
    assert any(
        "FACET 5" in reference_facet_profile(points) or "FACET 6" in reference_facet_profile(points)
        for points in CASES
    )
    assert "FACET_HASH" in reference_facet_profile(CASES[0])
    assert "TRIPLE_SUPPORT_HASH" in reference_facet_profile(CASES[0])
    assert MODES == {"simplicial-only", "interior-as-hull", "floating-orientation"}
