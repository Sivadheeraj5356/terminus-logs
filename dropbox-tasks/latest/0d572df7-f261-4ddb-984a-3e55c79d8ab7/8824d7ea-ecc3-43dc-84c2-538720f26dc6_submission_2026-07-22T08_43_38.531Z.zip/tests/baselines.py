MODES = {"simplicial-only", "interior-as-hull", "floating-orientation"}
