# Rank-four polytope face-incidence profile

Input is N followed by N distinct integer points in R4. Use 5 <= N <= 16, coordinate magnitude at most 10000, and a full-dimensional convex polytope. Some points may be interior and a facet may contain more than four input points.

For every four-point affine-independent subset, evaluate the exact four-dimensional determinant against every input point. It is supporting when all points lie on one side of its affine hyperplane. Merge all supporting subsets having the same complete set of coplanar input IDs. Every merged set is a facet and contains at least four IDs.

Write HULL h followed by the increasing one-based IDs that occur in at least one merged facet. Then write FACETS f and one line FACET k i1 ... ik for each merged facet. Sort facet lines lexicographically by their increasing ID lists.

After the facet rows, write `FACET_HASH H`. Start H at 17 and scan facets in output order, appending k and then every one-based facet ID. Then write `TRIPLE_SUPPORT_HASH T`. Start T at 31 and scan every increasing triple of hull vertex IDs in lexicographic order; append the three one-based IDs and the number of output facets that contain all three vertices. Both hashes use modulus 1000000007 and base 1000003: appending x means `H = (H * 1000003 + x) mod 1000000007`, and the same update rule applies to T. End with one newline and no other output.
