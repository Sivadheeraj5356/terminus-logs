#include <algorithm>
#include <iostream>
#include <set>
#include <vector>

using I = __int128_t;
const long long HASH_MOD = 1000000007LL;
const long long HASH_BASE = 1000003LL;
struct P { long long x[4]; };
I det4(I a[4][4]) {
    I result = 0;
    for (int col = 0; col < 4; ++col) {
        I m[3][3];
        for (int r = 1; r < 4; ++r) { int c2 = 0; for (int c = 0; c < 4; ++c) if (c != col) m[r - 1][c2++] = a[r][c]; }
        I minor = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
        result += (col % 2 ? -1 : 1) * a[0][col] * minor;
    }
    return result;
}
I orient(const P& a, const P& b, const P& c, const P& d, const P& q) {
    I m[4][4]; const P* base[4] = {&b, &c, &d, &q};
    for (int r = 0; r < 4; ++r) for (int j = 0; j < 4; ++j) m[r][j] = I(base[r]->x[j]) - a.x[j];
    return det4(m);
}
long long append_hash(long long h, long long value) {
    value %= HASH_MOD;
    if (value < 0) value += HASH_MOD;
    return (h * HASH_BASE + value) % HASH_MOD;
}

int main() {
    std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
    int n; if (!(std::cin >> n)) return 1;
    std::vector<P> p(n); for (auto& q : p) for (long long& x : q.x) std::cin >> x;
    std::set<std::vector<int>> facets;
    for (int i = 0; i < n; ++i) for (int j = i + 1; j < n; ++j) for (int k = j + 1; k < n; ++k) for (int l = k + 1; l < n; ++l) {
        bool positive = false, negative = false;
        for (int q = 0; q < n; ++q) { I value = orient(p[i], p[j], p[k], p[l], p[q]); positive |= value > 0; negative |= value < 0; }
        if (positive && negative) continue;
        if (!positive && !negative) continue;
        std::vector<int> ids;
        for (int q = 0; q < n; ++q) if (!orient(p[i], p[j], p[k], p[l], p[q])) ids.push_back(q);
        if (ids.size() >= 4) facets.insert(ids);
    }
    std::set<int> hull;
    for (const auto& f : facets) hull.insert(f.begin(), f.end());
    std::cout << "HULL " << hull.size(); for (int x : hull) std::cout << ' ' << x + 1; std::cout << '\n';
    std::cout << "FACETS " << facets.size() << '\n';
    for (const auto& f : facets) { std::cout << "FACET " << f.size(); for (int x : f) std::cout << ' ' << x + 1; std::cout << '\n'; }
    long long facet_hash = 17;
    for (const auto& f : facets) {
        facet_hash = append_hash(facet_hash, (long long)f.size());
        for (int x : f) facet_hash = append_hash(facet_hash, x + 1);
    }
    std::vector<int> hull_ids(hull.begin(), hull.end());
    long long support_hash = 31;
    for (int a = 0; a < (int)hull_ids.size(); ++a) {
        for (int b = a + 1; b < (int)hull_ids.size(); ++b) {
            for (int c = b + 1; c < (int)hull_ids.size(); ++c) {
                int count = 0;
                for (const auto& f : facets) {
                    if (std::binary_search(f.begin(), f.end(), hull_ids[a]) &&
                        std::binary_search(f.begin(), f.end(), hull_ids[b]) &&
                        std::binary_search(f.begin(), f.end(), hull_ids[c])) ++count;
                }
                support_hash = append_hash(support_hash, hull_ids[a] + 1);
                support_hash = append_hash(support_hash, hull_ids[b] + 1);
                support_hash = append_hash(support_hash, hull_ids[c] + 1);
                support_hash = append_hash(support_hash, count);
            }
        }
    }
    std::cout << "FACET_HASH " << facet_hash << '\n';
    std::cout << "TRIPLE_SUPPORT_HASH " << support_hash << '\n';
}
