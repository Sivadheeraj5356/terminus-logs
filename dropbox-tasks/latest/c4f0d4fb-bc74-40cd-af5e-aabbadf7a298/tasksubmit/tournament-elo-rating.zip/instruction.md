Implement the tournament Elo rating pipeline in the Rust workspace under /app/environment so elo_verify emits a contract-compliant JSON report from the bundled match trace.

Rebuild with /app/environment/scripts/rebuild.sh before running the verifier. Read /app/docs/contract.md for the output schema, /app/docs/pipeline_stages.md for stage responsibilities and workspace paths, and /app/docs/elo_formula.md for rating math and aggregate fields.

Do not modify sources under tools/elo_verify/ or traces/. Tests consume /tmp/test_report.json after a successful elo_verify run.
