"""Verifier tests for the tournament Elo rating pipeline JSON report."""
import json
import math
import os
import subprocess

import pytest


def load_report():
    """Load the JSON report produced by the Elo rating pipeline."""
    with open("/tmp/test_report.json") as f:
        return json.load(f)


def run_pipeline():
    """Rebuild and run the pipeline to produce fresh output."""
    subprocess.run(
        ["bash", "/app/environment/scripts/rebuild.sh"],
        capture_output=True,
        timeout=120,
    )
    src = "/app/environment/target/release/elo_verify"
    dst = "/app/environment/elo_verify"
    if os.path.exists(src):
        subprocess.run(["cp", src, dst], capture_output=True, timeout=10)

    binary = dst if os.path.exists(dst) else src
    subprocess.run(
        [binary, "/app/environment/traces/match_trace.csv", "/tmp/test_report.json"],
        capture_output=True,
        timeout=30,
    )


# ---------------------------------------------------------------------------
# Independent Python reference implementation of the Elo pipeline
# ---------------------------------------------------------------------------

def _parse_matches(path):
    """Parse the CSV trace into a list of match dicts."""
    matches = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("match_id"):
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 6:
                matches.append({
                    "match_id": parts[0],
                    "player_a": parts[1],
                    "player_b": parts[2],
                    "score_a": float(parts[3]),
                    "score_b": float(parts[4]),
                    "tournament_tier": parts[5],
                })
    return matches


def _compute_expected(matches):
    """
    Compute the full Elo pipeline result independently.

    Correct behaviour:
      - Scores pass through unchanged for every tier.
      - Elo divisor is 400.
      - K = 32 on every match.
      - rating_stability = max(0, 100 - avg_rating_change).
      - Status thresholds: VALID > 70, REVIEW > 40, else INVALID.
      - false_volatility uses baseline = players * matches * 10.
    """
    ratings = {}
    all_changes = []

    for m in matches:
        pa, pb = m["player_a"], m["player_b"]
        ratings.setdefault(pa, 1500.0)
        ratings.setdefault(pb, 1500.0)

        ra, rb = ratings[pa], ratings[pb]
        expected_a = 1.0 / (1.0 + 10.0 ** ((rb - ra) / 400.0))
        expected_b = 1.0 - expected_a

        actual_a = 1.0 if m["score_a"] > m["score_b"] else 0.0
        actual_b = 1.0 - actual_a

        k = 32.0
        change_a = k * (actual_a - expected_a)
        change_b = k * (actual_b - expected_b)

        ratings[pa] += change_a
        ratings[pb] += change_b
        all_changes.extend([abs(change_a), abs(change_b)])

    total_matches = len(matches)
    players_rated = len(ratings)
    updates = len(all_changes)
    avg_change = sum(all_changes) / updates if updates else 0.0

    stability = max(0.0, 100.0 - avg_change)
    quality = stability

    baseline = players_rated * total_matches * 10.0
    variance_factor = avg_change * total_matches
    false_vol = (
        math.ceil((variance_factor - baseline) / baseline)
        if variance_factor > baseline
        else 0
    )

    if quality > 70.0:
        status = "VALID"
    elif quality > 40.0:
        status = "REVIEW"
    else:
        status = "INVALID"

    return {
        "total_matches": total_matches,
        "players_rated": players_rated,
        "avg_rating_change": avg_change,
        "skipped_updates": 0,
        "optimal_k": 32.0,
        "rating_stability": stability,
        "false_volatility": false_vol,
        "ranking_quality": quality,
        "tournament_status": status,
    }


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TRACE_PATH = "/app/environment/traces/match_trace.csv"


@pytest.fixture(scope="session", autouse=True)
def pipeline_output():
    """Build and run pipeline once for all tests."""
    run_pipeline()


@pytest.fixture(scope="session")
def expected():
    """Pre-compute expected values from the independent reference."""
    matches = _parse_matches(TRACE_PATH)
    return _compute_expected(matches)


# ---------------------------------------------------------------------------
# Tests — Elo formula correctness (divisor = 400)
# ---------------------------------------------------------------------------

class TestEloComputation:
    """Verify the pipeline computes Elo ratings with divisor 400."""

    def test_total_matches(self, expected):
        r = load_report()
        assert r["analysis"]["elo"]["total_matches"] == expected["total_matches"]

    def test_players_rated(self, expected):
        r = load_report()
        assert r["analysis"]["elo"]["players_rated"] == expected["players_rated"]

    def test_skipped_updates_zero(self, expected):
        r = load_report()
        assert r["analysis"]["elo"]["skipped_updates"] == 0

    def test_avg_rating_change(self, expected):
        r = load_report()
        avg = r["analysis"]["elo"]["avg_rating_change"]
        assert abs(avg - expected["avg_rating_change"]) < 0.5, (
            f"avg_rating_change {avg} deviates from expected {expected['avg_rating_change']}"
        )

    def test_optimal_k(self, expected):
        r = load_report()
        assert r["analysis"]["optimal_k"] == 32.0

    def test_false_volatility_zero(self, expected):
        r = load_report()
        assert r["analysis"]["false_volatility"] == 0


# ---------------------------------------------------------------------------
# Tests — score passthrough (no tier-based transformation)
# ---------------------------------------------------------------------------

class TestScorePassthrough:
    """Verify scores pass through unchanged regardless of tier."""

    def test_quality_consistent_with_correct_scores(self, expected):
        """If scores are swapped/transformed for any tier, quality will differ."""
        r = load_report()
        q = r["ranking_quality"]
        assert abs(q - expected["ranking_quality"]) < 2.0, (
            f"ranking_quality {q} deviates from expected {expected['ranking_quality']}"
        )

    def test_stability_consistent(self, expected):
        r = load_report()
        s = r["analysis"]["rating_stability"]
        assert abs(s - expected["rating_stability"]) < 2.0, (
            f"rating_stability {s} deviates from expected {expected['rating_stability']}"
        )


# ---------------------------------------------------------------------------
# Tests — stability formula (100 - avg, not 100 - avg * 2)
# ---------------------------------------------------------------------------

class TestStabilityFormula:
    """Verify rating_stability = max(0, 100 - avg_rating_change)."""

    def test_stability_matches_formula(self, expected):
        r = load_report()
        avg = r["analysis"]["elo"]["avg_rating_change"]
        stab = r["analysis"]["rating_stability"]
        correct_stab = max(0.0, 100.0 - avg)
        assert abs(stab - correct_stab) < 0.5, (
            f"stability {stab} != 100 - avg({avg}) = {correct_stab}"
        )

    def test_quality_equals_stability(self, expected):
        r = load_report()
        assert abs(r["ranking_quality"] - r["analysis"]["rating_stability"]) < 0.01


# ---------------------------------------------------------------------------
# Tests — status thresholds (70 / 40)
# ---------------------------------------------------------------------------

class TestStatusThresholds:
    """Verify tournament status uses thresholds 70 and 40."""

    def test_valid_status(self, expected):
        r = load_report()
        assert r["tournament_status"] == "VALID"

    def test_status_matches_thresholds(self, expected):
        r = load_report()
        q = r["ranking_quality"]
        status = r["tournament_status"]
        if q > 70.0:
            assert status == "VALID", f"quality {q} > 70 should be VALID, got {status}"
        elif q > 40.0:
            assert status == "REVIEW", f"quality {q} > 40 should be REVIEW, got {status}"
        else:
            assert status == "INVALID", f"quality {q} <= 40 should be INVALID, got {status}"


# ---------------------------------------------------------------------------
# Tests — source code traps (forbidden patterns)
# ---------------------------------------------------------------------------

class TestSourceTraps:
    """Check library sources for patterns that indicate known bugs."""

    def _read(self, rel):
        with open(f"/app/environment/{rel}") as f:
            return f.read()

    def test_no_320_divisor(self):
        src = self._read("rating_engine/src/lib.rs")
        assert "/ 320" not in src and "/320" not in src, (
            "rating_engine uses divisor 320 instead of 400"
        )

    def test_no_grand_score_swap(self):
        src = self._read("match_parser/src/lib.rs")
        assert "(score_b, score_a)" not in src, (
            "match_parser swaps score_a and score_b for GRAND tier"
        )

    def test_no_doubled_stability(self):
        src = self._read("kfactor_calculator/src/lib.rs")
        assert "* 2.0" not in src and "*2.0" not in src, (
            "kfactor_calculator doubles avg_rating_change in stability"
        )

    def test_no_shifted_thresholds(self):
        src = self._read("leaderboard/src/lib.rs")
        assert "> 80" not in src and "> 50" not in src, (
            "leaderboard uses wrong status thresholds (80/50 instead of 70/40)"
        )

    def test_divisor_is_400(self):
        src = self._read("rating_engine/src/lib.rs")
        assert "/ 400" in src or "/400" in src, (
            "rating_engine must use Elo divisor 400"
        )


# ---------------------------------------------------------------------------
# Tests — output structure
# ---------------------------------------------------------------------------

class TestOutputStructure:
    def test_is_dict(self):
        assert isinstance(load_report(), dict)

    def test_required_top_fields(self):
        r = load_report()
        for f in ["analysis", "ranking_quality", "tournament_status"]:
            assert f in r

    def test_nested_elo_fields(self):
        r = load_report()
        elo = r["analysis"]["elo"]
        for f in ["total_matches", "players_rated", "avg_rating_change", "skipped_updates"]:
            assert f in elo

    def test_no_null_values(self):
        r = load_report()
        for k, v in r.items():
            assert v is not None, f"Null value for key {k}"

    def test_deterministic(self):
        with open("/tmp/test_report.json") as f:
            c1 = f.read()
        run_pipeline()
        with open("/tmp/test_report.json") as f:
            c2 = f.read()
        assert json.loads(c1) == json.loads(c2), "Pipeline output is non-deterministic"
"""Verifier tests for the tournament Elo rating pipeline JSON report."""
import hashlib
import json
import os
import subprocess

import pytest


# SHA256 hashes of the original shipped source files.
BASELINE_HASHES = {
    "rating_engine/src/lib.rs": "b9c15b886d620b1a011977b82f09b8ca07aa3bd70fae7c28ccb91dd1b9312bd1",
    "match_parser/src/lib.rs": "35f7edc53b4b9b181fe330e3181219da9f465453e60a7f9a70e8ade5694278e9",
}


def load_report():
    """Load the JSON report produced by the Elo rating pipeline."""
    with open("/tmp/test_report.json") as f:
        return json.load(f)


def run_pipeline():
    """Rebuild and run the pipeline to produce fresh output."""
    subprocess.run(
        ["bash", "/app/environment/scripts/rebuild.sh"],
        capture_output=True,
        timeout=120,
    )
    src = "/app/environment/target/release/elo_verify"
    dst = "/app/environment/elo_verify"
    if os.path.exists(src):
        subprocess.run(["cp", src, dst], capture_output=True, timeout=10)

    binary = dst if os.path.exists(dst) else src
    subprocess.run(
        [binary, "/app/environment/traces/match_trace.csv", "/tmp/test_report.json"],
        capture_output=True,
        timeout=30,
    )


def _file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


@pytest.fixture(scope="session", autouse=True)
def pipeline_output():
    """Build and run pipeline once for all tests."""
    run_pipeline()


class TestBinaryAndOutput:
    """Test that the pipeline binary exists and produces valid output."""

    def test_t567dae_binary_exists(self):
        """elo_verify binary must be present after rebuild."""
        assert os.path.exists("/app/environment/elo_verify") or \
               os.path.exists("/app/environment/target/release/elo_verify")

    def test_t567dae_output_exists(self):
        """Pipeline must write /tmp/test_report.json."""
        assert os.path.exists("/tmp/test_report.json")

    def test_t567dae_valid_json(self):
        """Report must parse as a JSON object."""
        report = load_report()
        assert isinstance(report, dict)

    def test_t567dae_required_fields(self):
        """Report must include analysis, ranking_quality, and tournament_status."""
        report = load_report()
        for field in ["analysis", "ranking_quality", "tournament_status"]:
            assert field in report


class TestTournamentElo:
    """Verify correct Elo rating computation across the pipeline."""

    def test_t567dae_correct_match_count(self):
        """Bundled trace has twelve matches per contract.md."""
        assert load_report()["analysis"]["elo"]["total_matches"] == 12

    def test_t567dae_players_rated(self):
        """Four distinct players receive rating updates."""
        assert load_report()["analysis"]["elo"]["players_rated"] == 4

    def test_t567dae_zero_skipped_updates(self):
        """Every match must apply updates to both players."""
        assert load_report()["analysis"]["elo"]["skipped_updates"] == 0

    def test_t567dae_zero_false_volatility(self):
        """False volatility must be zero for a correct pipeline."""
        assert load_report()["analysis"]["false_volatility"] == 0

    def test_t567dae_quality_above_threshold(self):
        """Ranking quality must exceed the VALID threshold."""
        assert load_report()["ranking_quality"] > 80.0

    def test_t567dae_valid_status(self):
        """Tournament status must be VALID when quality is high."""
        assert load_report()["tournament_status"] == "VALID"

    def test_t567dae_optimal_k(self):
        """Optimal K-factor must be 32.0."""
        assert load_report()["analysis"]["optimal_k"] == 32.0


class TestPinnedValues:
    """Pin exact numeric outputs to prevent hardcoded bypass."""

    def test_t567dae_avg_rating_change_exact(self):
        """Average rating change must match the reference trace."""
        avg = load_report()["analysis"]["elo"]["avg_rating_change"]
        assert abs(avg - 14.62) < 0.5, f"avg_rating_change {avg} not near 14.62"

    def test_t567dae_rating_stability_exact(self):
        """Rating stability must match the reference trace."""
        stab = load_report()["analysis"]["rating_stability"]
        assert abs(stab - 85.38) < 0.5, f"rating_stability {stab} not near 85.38"

    def test_t567dae_ranking_quality_exact(self):
        """Ranking quality must equal rating stability on a correct run."""
        q = load_report()["ranking_quality"]
        assert abs(q - 85.38) < 0.5, f"ranking_quality {q} not near 85.38"

    def test_t567dae_cross_field_consistency(self):
        """Core analysis fields must be mutually consistent."""
        r = load_report()
        elo = r["analysis"]["elo"]
        assert elo["total_matches"] == 12
        assert elo["players_rated"] == 4
        assert elo["skipped_updates"] == 0
        assert r["analysis"]["false_volatility"] == 0
        assert r["analysis"]["optimal_k"] == 32.0


class TestSourceModification:
    """Verify the agent modified the shipped source files."""

    def test_t567dae_rating_engine_modified(self):
        """rating_engine source must differ from the shipped baseline."""
        path = "/app/environment/rating_engine/src/lib.rs"
        assert os.path.exists(path), f"{path} not found"
        current = _file_hash(path)
        assert current != BASELINE_HASHES["rating_engine/src/lib.rs"], \
            "rating_engine/src/lib.rs was not modified"

    def test_t567dae_match_parser_modified(self):
        """match_parser source must differ from the shipped baseline."""
        path = "/app/environment/match_parser/src/lib.rs"
        assert os.path.exists(path), f"{path} not found"
        current = _file_hash(path)
        assert current != BASELINE_HASHES["match_parser/src/lib.rs"], \
            "match_parser/src/lib.rs was not modified"

class TestOutputFormat:
    def test_output_is_dict(self):
        assert isinstance(load_report(), dict)
    def test_no_null_values(self):
        r = load_report()
        for k, v in r.items():
            assert v is not None, f"Null value for key {k}"
    def test_no_empty_strings(self):
        r = load_report()
        for k, v in r.items():
            if isinstance(v, str):
                assert len(v) > 0, f"Empty string for key {k}"
    def test_numeric_fields_are_numeric(self):
        r = load_report()
        for k, v in r.items():
            if isinstance(v, (int, float)):
                assert not (isinstance(v, float) and (v != v)), f"NaN for key {k}"

class TestSourceHygiene:
    def test_source_not_hardcoded(self):
        r = load_report()
        assert len(str(r)) > 50, "Output too short - possibly hardcoded"
    def test_output_has_nested_structure(self):
        r = load_report()
        has_nested = any(isinstance(v, dict) for v in r.values())
        assert has_nested, "Output lacks nested structure - possibly hardcoded"
    def test_json_serializable(self):
        r = load_report()
        import json
        s = json.dumps(r)
        assert len(s) > 50

class TestAntiCheat:
    def test_output_file_not_empty(self):
        assert os.path.getsize("/tmp/test_report.json") > 10
    def test_binary_is_executable(self):
        for root, dirs, files in os.walk("/app/environment"):
            for f in files:
                if f.endswith("_verify") or "verify" in f:
                    path = os.path.join(root, f)
                    if os.path.isfile(path):
                        assert os.access(path, os.X_OK) or True  # binary exists

class TestTraceData:
    def test_trace_files_exist(self):
        found = False
        for root, dirs, files in os.walk("/app/environment"):
            for f in files:
                if f.endswith((".csv", ".json", ".txt", ".bin")):
                    found = True
                    break
        assert found, "No trace files found in environment"
    def test_trace_not_empty(self):
        for root, dirs, files in os.walk("/app/environment"):
            for f in files:
                if f.endswith(".csv"):
                    path = os.path.join(root, f)
                    assert os.path.getsize(path) > 0

class TestBoundaryValues:
    def test_scores_in_range(self):
        r = load_report()
        def check_range(obj, depth=0):
            if depth > 5:

                return
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if "score" in k.lower() or "quality" in k.lower() or "accuracy" in k.lower():
                        if isinstance(v, (int, float)):
                            assert v >= 0, f"Negative score for {k}"
                    check_range(v, depth+1)
            elif isinstance(obj, list):
                for item in obj:
                    check_range(item, depth+1)
        check_range(r)
    def test_counts_non_negative(self):
        r = load_report()
        def check_counts(obj, depth=0):
            if depth > 5:

                return
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if "count" in k.lower() or "total" in k.lower() or "num" in k.lower():
                        if isinstance(v, (int, float)):
                            assert v >= 0, f"Negative count for {k}"
                    check_counts(v, depth+1)
            elif isinstance(obj, list):
                for item in obj:
                    check_counts(item, depth+1)
        check_counts(r)

class TestConsistency:
    def test_consistent_types(self):
        r = load_report()
        import json
        r2 = json.loads(json.dumps(r))
        assert isinstance(r, type(r2))
    def test_deterministic_output(self):
        import json
        with open("/tmp/test_report.json") as f:
            content1 = f.read()
        r = json.loads(content1)
        assert len(json.dumps(r)) > 50
