#!/usr/bin/env bash

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

cat > /logs/verifier/ctrf.json << 'CTRF'
{"results":{"tool":{"name":"pytest"},"summary":{"tests":0,"passed":0,"failed":0,"pending":0,"skipped":0,"other":0},"tests":[]}}
CTRF

if [ "$PWD" = "/" ]; then
    echo "Error: No working directory set."
    echo 0 > /logs/verifier/reward.txt
    exit 0
fi

cd /app

bash /app/environment/scripts/rebuild.sh 2>&1 || {
    echo "Error: cargo build failed"
    echo 0 > /logs/verifier/reward.txt
    exit 0
}

if [ -f /app/environment/target/release/elo_verify ]; then
    cp /app/environment/target/release/elo_verify /app/environment/elo_verify
fi

set +e
python3 -m pytest --ctrf /logs/verifier/ctrf.json "${TEST_DIR:-/tests}/test_outputs.py" -rA -v
rc=$?
if [ "$rc" -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
else
    echo 0 > /logs/verifier/reward.txt
fi
