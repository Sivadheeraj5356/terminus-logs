# Elo formula reference

## Expected score

For player A versus player B with ratings Ra and Rb:

expected_a = 1 / (1 + 10^((Rb - Ra) / 400))

expected_b = 1 - expected_a

## Update

change_a = K * (actual_a - expected_a)

change_b = K * (actual_b - expected_b)

K is 32 for every match.

## Aggregates

- avg_rating_change: mean of absolute per-player changes across all updates
- skipped_updates: must be 0 when every match updates both players
- rating_stability: max(0, 100 - avg_rating_change)
- ranking_quality: equals rating_stability
- tournament_status: VALID when ranking_quality > 70
