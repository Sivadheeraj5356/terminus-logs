# Tournament Elo Rating Pipeline Contract

## Pipeline overview

The workspace under /app/environment implements a four-stage pipeline:

1. match_parser — parse CSV match rows
2. rating_engine — compute Elo updates
3. kfactor_calculator — derive stability metrics
4. leaderboard — emit the tournament JSON report

The verifier binary elo_verify reads a trace CSV and writes a JSON report. Do not modify sources under tools/elo_verify/ or traces/.

## Input format

CSV columns: match_id, player_a, player_b, score_a, score_b, tournament_tier

Score comparison is binary: if `score_a > score_b` then `actual_a = 1.0` (win) and `actual_b = 0.0` (loss); otherwise `actual_a = 0.0` and `actual_b = 1.0`. Equal scores (draws) are resolved as a win for `player_b`. Each player's score column is used as-is for the win/loss determination regardless of tournament tier.

## Rating rules

- Initial rating for a new player: 1500
- K-factor: 32 on every match
- Every match applies updates to both players; skipped_updates in the report must be 0 for a valid run
- Process matches in file order with a constant K-factor on every row

## Output schema

```json
{
  "analysis": {
    "elo": {
      "total_matches": <integer>,
      "players_rated": <integer>,
      "avg_rating_change": <float>,
      "skipped_updates": <integer>
    },
    "optimal_k": <float>,
    "rating_stability": <float>,
    "false_volatility": <integer>
  },
  "ranking_quality": <float>,
  "tournament_status": "<VALID|REVIEW|INVALID>"
}
```

## Field definitions

- total_matches: matches processed (12 for the bundled trace)
- players_rated: distinct players receiving updates (4 for the bundled trace)
- avg_rating_change: mean absolute rating delta per player-update
- skipped_updates: player-updates not applied (must be 0)
- optimal_k: 32.0
- rating_stability: 100.0 minus avg_rating_change (minimum 0)
- false_volatility: 0 when the rating system is stable
- ranking_quality: equals rating_stability
- tournament_status: VALID when ranking_quality exceeds the upper threshold, REVIEW between the two thresholds, INVALID at or below the lower threshold

## Build and run

Rebuild with /app/environment/scripts/rebuild.sh before running elo_verify. The verifier command shape is:

elo_verify <input_csv> <output_json>

Tests read the report from /tmp/test_report.json after a successful run.
