#!/bin/bash
set -euo pipefail

cat > /app/src/Policy.php <<'PHP'
<?php

declare(strict_types=1);

namespace TrustLab;

final class Policy
{
    private const BASE_HIGH_RISK = [
        'prize', 'winner', 'urgent', 'claim', 'verify', 'suspended', 'congratulations',
        'selected', 'guaranteed', 'lottery', 'won', 'otp', 'kyc', 'ifsc', 'giro',
        'sortcode', 'chargeback', 'overdraft', 'topup', 'iban', 'swift', 'bic',
        'routing', 'cvv', 'ssn', 'netbanking', 'upi', 'payee', 'mandate', 'payout',
        'reactivate', 'unlock', 'expire', 'free', 'refund', 'cash', 'credited',
        'reward', 'debited',
    ];

    private const BASE_SAFE_HARBOUR = [
        'receipt', 'invoice', 'appointment', 'booking', 'dispatch', 'itinerary',
        'reservation', 'renewal', 'enrolment', 'ticket', 'boarding', 'tracking',
        'notice',
    ];

    // [id, effective_date, kind, ...payload]
    private const AMENDMENTS = [
        ['AMD-001', '2024-02-05', 'remove', 'free', 'H'],
        ['AMD-002', '2024-01-16', 'add', 'payid', 'H'],
        ['AMD-003', '2024-04-02', 'add', 'seizure', 'H'],
        ['AMD-004', '2024-02-27', 'add', 'hold', 'H'],
        ['AMD-005', '2024-03-11', 'move', 'refund', 'H', 'S'],
        ['AMD-006', '2024-06-25', 'add', 'jackpot', 'H'],
        ['AMD-007', '2024-04-23', 'remove', 'cash', 'H'],
        ['AMD-008', '2024-05-14', 'add', 'confirmation', 'S'],
        ['AMD-009', '2024-06-03', 'remove', 'notice', 'S'],
        ['AMD-010', '2024-11-18', 'void', 'AMD-006'],
        ['AMD-011', '2024-07-15', 'cond', 'hold', 'H', ['remove', 'hold', 'H'], ['noop']],
        ['AMD-012', '2024-08-06', 'move', 'credited', 'H', 'S'],
        ['AMD-013', '2024-09-02', 'remove', 'reward', 'H'],
        ['AMD-014', '2024-09-24', 'add', 'checkin', 'S'],
        ['AMD-015', '2024-10-14', 'remove', 'debited', 'H'],
        ['AMD-016', '2024-05-02', 'add', 'bonus', 'H'],
        ['AMD-017', '2024-12-09', 'void', 'AMD-016'],
        ['AMD-018', '2024-10-30', 'add', 'forfeit', 'H'],
        ['AMD-019', '2025-01-13', 'cond', 'confirmation', 'S', ['add', 'rebate', 'S'], ['add', 'rebate', 'H']],
        ['AMD-020', '2025-02-10', 'remove', 'topup', 'H'],
        ['AMD-021', '2024-07-29', 'add', 'wire', 'H'],
        ['AMD-022', '2025-03-04', 'move', 'wire', 'H', 'S'],
        ['AMD-023', '2024-08-20', 'add', 'escrow', 'H'],
        ['AMD-024', '2025-03-25', 'void', 'AMD-023'],
    ];

    private static array $cache = [];

    private static function sortedAmendments(): array
    {
        $amendments = self::AMENDMENTS;
        usort($amendments, static function (array $a, array $b): int {
            return $a[1] === $b[1] ? strcmp($a[0], $b[0]) : strcmp($a[1], $b[1]);
        });
        return $amendments;
    }

    public static function maxRevision(): int
    {
        return count(self::AMENDMENTS);
    }

    public static function isValidRevision(int $revision): bool
    {
        return $revision >= 0 && $revision <= self::maxRevision();
    }

    private static function applyAction(array $action, array &$high, array &$safe): void
    {
        switch ($action[0]) {
            case 'add':
                if ($action[2] === 'H') { $high[$action[1]] = true; } else { $safe[$action[1]] = true; }
                break;
            case 'remove':
                if ($action[2] === 'H') { unset($high[$action[1]]); } else { unset($safe[$action[1]]); }
                break;
            case 'move':
                if ($action[2] === 'H') { unset($high[$action[1]]); $safe[$action[1]] = true; }
                else { unset($safe[$action[1]]); $high[$action[1]] = true; }
                break;
            case 'noop':
            default:
                break;
        }
    }

    public static function registersAt(int $revision): array
    {
        if (isset(self::$cache[$revision])) {
            return self::$cache[$revision];
        }
        $revision = max(0, min($revision, self::maxRevision()));
        $scope = array_slice(self::sortedAmendments(), 0, $revision);

        $voided = [];
        foreach ($scope as $a) {
            if ($a[2] === 'void') { $voided[$a[3]] = true; }
        }

        $high = [];
        foreach (self::BASE_HIGH_RISK as $t) { $high[$t] = true; }
        $safe = [];
        foreach (self::BASE_SAFE_HARBOUR as $t) { $safe[$t] = true; }

        foreach ($scope as $a) {
            if ($a[2] === 'void') { continue; }
            if (isset($voided[$a[0]])) { continue; }
            if ($a[2] === 'cond') {
                $present = $a[4] === 'H' ? isset($high[$a[3]]) : isset($safe[$a[3]]);
                self::applyAction($present ? $a[5] : $a[6], $high, $safe);
            } elseif ($a[2] === 'move') {
                self::applyAction(['move', $a[3], $a[4], $a[5]], $high, $safe);
            } else {
                self::applyAction([$a[2], $a[3], $a[4]], $high, $safe);
            }
        }

        self::$cache[$revision] = [$high, $safe];
        return self::$cache[$revision];
    }

    public static function disposition(string $gold, string $message, int $revision): string
    {
        [$high, $safe] = self::registersAt($revision);

        $h = 0;
        $s = 0;
        foreach (array_unique(Classifier::tokenize($message)) as $token) {
            if (isset($high[$token])) { $h++; }
            if (isset($safe[$token])) { $s++; }
        }

        if ($h >= 2) { return 'block'; }
        if ($h >= 1 && $s >= 1) { return 'allow'; }
        if ($gold === 'spam' && $h === 1) { return 'quarantine'; }
        if ($gold === 'spam' && $h === 0) { return 'block'; }
        return 'allow';
    }
}
PHP

cat > /app/src/ModelCodec.php <<'PHP'
<?php

declare(strict_types=1);

namespace TrustLab;

final class ModelCodec
{
    private const MAGIC = 'TLM1';
    private const VERSION = 3;

    private static function fnv1a32(string $data): int
    {
        $h = 0x811C9DC5;
        for ($i = 0, $n = strlen($data); $i < $n; $i++) {
            $h ^= ord($data[$i]);
            $h = ($h * 0x01000193) & 0xFFFFFFFF;
        }
        return $h;
    }

    public static function write(array $model, string $path): void
    {
        $classes = $model['classes'];
        $words = $model['words'];
        $totals = $model['class_totals'];

        $names = array_keys($classes);
        sort($names, SORT_STRING);

        $vocab = [];
        foreach ($words as $perClass) {
            foreach ($perClass as $token => $_) { $vocab[$token] = true; }
        }
        $tokens = array_keys($vocab);
        sort($tokens, SORT_STRING);

        $buf = self::MAGIC;
        $buf .= pack('v', self::VERSION);
        $buf .= pack('v', count($names));
        $buf .= pack('V', count($tokens));
        $buf .= pack('P', (int) $model['total']);

        foreach ($names as $name) {
            $buf .= pack('C', strlen($name)) . $name;
            $buf .= pack('P', (int) $classes[$name]);
            $buf .= pack('P', (int) ($totals[$name] ?? 0));
        }

        foreach ($tokens as $token) {
            $buf .= pack('C', strlen($token)) . $token;
            foreach ($names as $name) {
                $buf .= pack('P', (int) ($words[$name][$token] ?? 0));
            }
        }

        $buf .= pack('V', self::fnv1a32($buf));

        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        file_put_contents($path, $buf);
    }

    public static function read(string $path): array
    {
        $raw = file_get_contents($path);
        if ($raw === false || strlen($raw) < 24) {
            throw new \RuntimeException("cannot read model: {$path}");
        }
        if (substr($raw, 0, 4) !== self::MAGIC) {
            throw new \RuntimeException("bad magic in {$path}");
        }
        $body = substr($raw, 0, -4);
        $trailer = unpack('Vsum', substr($raw, -4));
        if ($trailer['sum'] !== self::fnv1a32($body)) {
            throw new \RuntimeException("checksum mismatch in {$path}");
        }

        $off = 4;
        $head = unpack('vversion/vclasses/Vvocab', substr($raw, $off, 8));
        $off += 8;
        $total = unpack('Ptotal', substr($raw, $off, 8))['total'];
        $off += 8;

        $names = [];
        $classes = [];
        $classTotals = [];
        for ($i = 0; $i < $head['classes']; $i++) {
            $len = ord($raw[$off]);
            $off += 1;
            $name = substr($raw, $off, $len);
            $off += $len;
            $classes[$name] = unpack('Pv', substr($raw, $off, 8))['v'];
            $off += 8;
            $classTotals[$name] = unpack('Pv', substr($raw, $off, 8))['v'];
            $off += 8;
            $names[] = $name;
        }

        $words = [];
        foreach ($names as $name) { $words[$name] = []; }
        for ($i = 0; $i < $head['vocab']; $i++) {
            $len = ord($raw[$off]);
            $off += 1;
            $token = substr($raw, $off, $len);
            $off += $len;
            foreach ($names as $name) {
                $count = unpack('Pv', substr($raw, $off, 8))['v'];
                $off += 8;
                if ($count > 0) {
                    $words[$name][$token] = $count;
                }
            }
        }

        return [
            'classes' => $classes,
            'words' => $words,
            'class_totals' => $classTotals,
            'vocab_size' => $head['vocab'],
            'total' => $total,
        ];
    }
}
PHP

cat > /app/src/DatasetResolver.php <<'PHP'
<?php

declare(strict_types=1);

namespace TrustLab;

final class DatasetResolver
{
    public static function isApproved(string $ref, array $approved): bool
    {
        if (!preg_match('/^[a-z0-9_]+$/', $ref)) {
            return false;
        }
        return in_array($ref, $approved, true);
    }

    public static function path(string $ref, string $registryDir, array $approved): string
    {
        if (!self::isApproved($ref, $approved)) {
            throw new \InvalidArgumentException("dataset not approved: {$ref}");
        }
        return rtrim($registryDir, '/') . '/datasets/' . $ref . '.tsv';
    }

    public static function load(string $ref, string $registryDir, array $approved): array
    {
        $path = self::path($ref, $registryDir, $approved);
        $raw = file_get_contents($path);
        if ($raw === false) {
            throw new \RuntimeException("cannot read dataset: {$path}");
        }
        $rows = [];
        foreach (explode("\n", $raw) as $line) {
            $line = rtrim($line, "\r");
            if ($line === '') {
                continue;
            }
            $tab = strpos($line, "\t");
            if ($tab === false) {
                continue;
            }
            $rows[] = [substr($line, 0, $tab), substr($line, $tab + 1)];
        }
        return $rows;
    }
}
PHP

cat > /app/src/Database.php <<'PHP'
<?php

declare(strict_types=1);

namespace TrustLab;

use PDO;

final class Database
{
    public static function connect(string $path): PDO
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        $pdo = new PDO('sqlite:' . $path);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA journal_mode=WAL;');
        $pdo->exec('PRAGMA busy_timeout=5000;');
        return $pdo;
    }

    public static function migrate(PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dataset_ref TEXT NOT NULL,
                policy_revision INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT \'queued\',
                progress INTEGER NOT NULL DEFAULT 0,
                model_path TEXT,
                metrics TEXT,
                error TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );'
        );

        $columns = $pdo->query('PRAGMA table_info(jobs)')->fetchAll();
        $names = array_column($columns, 'name');
        if (!in_array('policy_revision', $names, true)) {
            $pdo->exec('ALTER TABLE jobs ADD COLUMN policy_revision INTEGER NOT NULL DEFAULT 0');
        }
    }
}
PHP

cat > /app/src/JobRepository.php <<'PHP'
<?php

declare(strict_types=1);

namespace TrustLab;

use PDO;

final class JobRepository
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    private function now(): string
    {
        return gmdate('Y-m-d\TH:i:s\Z');
    }

    public function enqueue(string $datasetRef, int $policyRevision): int
    {
        $now = $this->now();
        $stmt = $this->pdo->prepare(
            'INSERT INTO jobs (dataset_ref, policy_revision, status, progress, created_at, updated_at)
             VALUES (:ref, :rev, \'queued\', 0, :c, :u)'
        );
        $stmt->execute([':ref' => $datasetRef, ':rev' => $policyRevision, ':c' => $now, ':u' => $now]);
        return (int) $this->pdo->lastInsertId();
    }

    public function claimNext(): ?array
    {
        $this->pdo->beginTransaction();
        try {
            $row = $this->pdo->query(
                'SELECT * FROM jobs WHERE status = \'queued\' ORDER BY id ASC LIMIT 1'
            )->fetch();
            if ($row === false) {
                $this->pdo->commit();
                return null;
            }
            $stmt = $this->pdo->prepare(
                'UPDATE jobs SET status = \'running\', progress = 5, updated_at = :u WHERE id = :id'
            );
            $stmt->execute([':u' => $this->now(), ':id' => $row['id']]);
            $this->pdo->commit();
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
        return $this->get((int) $row['id']);
    }

    public function setProgress(int $id, int $progress): void
    {
        $stmt = $this->pdo->prepare('UPDATE jobs SET progress = :p, updated_at = :u WHERE id = :id');
        $stmt->execute([':p' => $progress, ':u' => $this->now(), ':id' => $id]);
    }

    public function complete(int $id, string $modelPath, array $metrics): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE jobs SET status = \'completed\', progress = 100, model_path = :m,
             metrics = :met, error = NULL, updated_at = :u WHERE id = :id'
        );
        $stmt->execute([
            ':m' => $modelPath,
            ':met' => json_encode($metrics, JSON_UNESCAPED_SLASHES),
            ':u' => $this->now(),
            ':id' => $id,
        ]);
    }

    public function fail(int $id, string $error): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE jobs SET status = \'failed\', error = :e, updated_at = :u WHERE id = :id'
        );
        $stmt->execute([':e' => $error, ':u' => $this->now(), ':id' => $id]);
    }

    public function get(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM jobs WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }
}
PHP

cat > /app/bin/enqueue.php <<'PHP'
<?php

declare(strict_types=1);

require __DIR__ . '/../src/autoload.php';

use TrustLab\Config;
use TrustLab\Database;
use TrustLab\DatasetResolver;
use TrustLab\JobRepository;
use TrustLab\Policy;

$ref = $argv[1] ?? '';
$revRaw = $argv[2] ?? '';

if ($ref === '' || $revRaw === '') {
    fwrite(STDERR, "usage: enqueue.php <dataset_ref> <policy_revision>\n");
    exit(2);
}

$config = Config::load();

if (!DatasetResolver::isApproved($ref, $config->approvedDatasets())) {
    fwrite(STDERR, "rejected: dataset_ref '{$ref}' is not an approved dataset\n");
    exit(1);
}

if (!preg_match('/^(0|[1-9][0-9]*)$/', $revRaw) || !Policy::isValidRevision((int) $revRaw)) {
    fwrite(STDERR, "rejected: policy_revision '{$revRaw}' is not a defined revision\n");
    exit(1);
}

$pdo = Database::connect($config->databasePath());
Database::migrate($pdo);

$id = (new JobRepository($pdo))->enqueue($ref, (int) $revRaw);
fwrite(STDOUT, json_encode(['job_id' => $id, 'status' => 'queued']) . "\n");
PHP

cat > /app/bin/worker.php <<'PHP'
<?php

declare(strict_types=1);

require __DIR__ . '/../src/autoload.php';

use TrustLab\Classifier;
use TrustLab\Config;
use TrustLab\Database;
use TrustLab\DatasetResolver;
use TrustLab\JobRepository;
use TrustLab\ModelCodec;
use TrustLab\Policy;

function macro_f1(array $gold, array $pred, array $classes): array
{
    $tp = $fp = $fn = [];
    foreach ($classes as $c) { $tp[$c] = 0; $fp[$c] = 0; $fn[$c] = 0; }
    foreach ($gold as $i => $g) {
        $p = $pred[$i];
        if ($p === $g) { $tp[$g]++; } else { if (isset($fp[$p])) { $fp[$p]++; } $fn[$g]++; }
    }
    $per = [];
    $sum = 0.0;
    foreach ($classes as $c) {
        $prec = ($tp[$c] + $fp[$c]) > 0 ? $tp[$c] / ($tp[$c] + $fp[$c]) : 0.0;
        $rec = ($tp[$c] + $fn[$c]) > 0 ? $tp[$c] / ($tp[$c] + $fn[$c]) : 0.0;
        $f = ($prec + $rec) > 0 ? 2 * $prec * $rec / ($prec + $rec) : 0.0;
        $per[$c] = round($f, 4);
        $sum += $f;
    }
    return ['macro_f1' => round($sum / count($classes), 4), 'per_class' => $per];
}

$config = Config::load();
$pdo = Database::connect($config->databasePath());
Database::migrate($pdo);
$repo = new JobRepository($pdo);

$dispositions = ['allow', 'block', 'quarantine'];
$dataDir = dirname($config->databasePath());

$processed = 0;
while (($job = $repo->claimNext()) !== null) {
    $id = (int) $job['id'];
    try {
        $revision = (int) $job['policy_revision'];
        if (!Policy::isValidRevision($revision)) {
            throw new \RuntimeException("undefined policy revision: {$revision}");
        }

        $repo->setProgress($id, 20);
        $rows = DatasetResolver::load(
            (string) $job['dataset_ref'],
            $config->registryDir(),
            $config->approvedDatasets()
        );

        $labeled = [];
        $derived = [];
        $counts = ['allow' => 0, 'block' => 0, 'quarantine' => 0];
        foreach ($rows as [$gold, $message]) {
            $disposition = Policy::disposition($gold, $message, $revision);
            $counts[$disposition] = ($counts[$disposition] ?? 0) + 1;
            $labeled[] = [$message, $disposition];
            $derived[] = $disposition;
        }

        $labelDir = $dataDir . '/labels';
        if (!is_dir($labelDir)) {
            mkdir($labelDir, 0775, true);
        }
        file_put_contents($labelDir . '/' . $revision . '.txt', implode("\n", $derived) . "\n");

        $train = [];
        $holdout = [];
        foreach ($labeled as $i => $example) {
            if ($i % 5 === 0) { $holdout[] = $example; } else { $train[] = $example; }
        }

        $repo->setProgress($id, 60);
        $model = Classifier::train($train);
        $modelPath = rtrim($config->modelDir(), '/') . '/r' . $revision . '.bin';
        ModelCodec::write($model, $modelPath);
        $repo->setProgress($id, 90);

        $gold = [];
        $pred = [];
        foreach ($holdout as [$message, $disposition]) {
            $gold[] = $disposition;
            $pred[] = Classifier::predict($model, $message);
        }
        $evaluation = macro_f1($gold, $pred, $dispositions);
        $evaluation['holdout_size'] = count($holdout);

        $metrics = [
            'dataset_ref' => (string) $job['dataset_ref'],
            'policy_revision' => $revision,
            'training_examples' => count($train),
            'label_counts' => $counts,
            'classes' => array_keys($counts),
            'evaluation' => $evaluation,
        ];
        $repo->complete($id, $modelPath, $metrics);
        $processed++;
        fwrite(STDOUT, "job {$id} rev {$revision} completed: labels=" . json_encode($counts)
            . " eval=" . json_encode($evaluation) . "\n");
    } catch (\Throwable $e) {
        $repo->fail($id, $e->getMessage());
        fwrite(STDERR, "job {$id} failed: " . $e->getMessage() . "\n");
    }
}

fwrite(STDOUT, "worker done, processed {$processed} job(s)\n");
PHP

cat > /app/bin/classify.php <<'PHP'
<?php

declare(strict_types=1);

require __DIR__ . '/../src/autoload.php';

use TrustLab\Classifier;
use TrustLab\Config;
use TrustLab\ModelCodec;
use TrustLab\Policy;

$revRaw = $argv[1] ?? '';
if (!preg_match('/^(0|[1-9][0-9]*)$/', $revRaw) || !Policy::isValidRevision((int) $revRaw)) {
    fwrite(STDERR, "usage: classify.php <policy_revision>\n");
    exit(2);
}

$config = Config::load();
$modelPath = rtrim($config->modelDir(), '/') . '/r' . ((int) $revRaw) . '.bin';

if (!is_file($modelPath)) {
    fwrite(STDERR, "no trained model at {$modelPath}\n");
    exit(1);
}

$model = ModelCodec::read($modelPath);

while (($line = fgets(STDIN)) !== false) {
    $line = rtrim($line, "\r\n");
    echo Classifier::predict($model, $line), "\n";
}
PHP

php /app/bin/migrate.php
php /app/bin/enqueue.php sms_spam 24
php /app/bin/enqueue.php sms_spam 6
php /app/bin/worker.php
