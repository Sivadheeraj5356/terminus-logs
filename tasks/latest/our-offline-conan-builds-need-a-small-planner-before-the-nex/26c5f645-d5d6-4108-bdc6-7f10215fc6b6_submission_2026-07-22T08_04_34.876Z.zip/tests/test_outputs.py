"""Behavioral verifier for the moderation model training pipeline.

The suite drives real training jobs through the SQLite queue and the PHP worker at
two policy revisions, then grades domain outcomes: the dispositions derived for the
corpus must match the moderation policy row for row at each revision, the persisted
model must be a conforming exchange-format artifact that this verifier can load and
run inference from on its own, and the pipeline must refuse to train on anything
other than an approved corpus at a defined revision.
"""

import hashlib
import json
import math
import re
import sqlite3
import struct
import subprocess
from collections import Counter
from pathlib import Path

import pytest

APP = Path("/app")
DATASET = APP / "registry" / "datasets" / "sms_spam.tsv"
DB = APP / "data" / "queue.db"
LABEL_DIR = APP / "data" / "labels"
MODEL_DIR = APP / "models"
ENQUEUE = APP / "bin" / "enqueue.php"
WORKER = APP / "bin" / "worker.php"
CLASSIFY = APP / "bin" / "classify.php"

PROBES = Path("/tests/probes.json")

DATASET_SHA256 = "235b4dc71661ac397a291a04af10ba88d4c42b20ade7af971f2b01c70f14aab8"
MACRO_F1_THRESHOLD = 0.78
AGREEMENT_THRESHOLD = 0.98
CLASSES = ["allow", "block", "quarantine"]
CURRENT_REVISION = 24
AUDIT_REVISION = 6
REVISIONS = [CURRENT_REVISION, AUDIT_REVISION]


def _php(args, stdin=None, timeout=300):
    return subprocess.run(
        ["php", *[str(a) for a in args]],
        input=stdin,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _job_id(stdout: str) -> int:
    lines = [ln for ln in stdout.splitlines() if ln.strip()]
    assert lines, "enqueue produced no output"
    return int(json.loads(lines[-1])["job_id"])


def _expected_labels(revision: int):
    return Path(f"/tests/expected_labels_r{revision}.txt").read_text().split()


def _tokenize(text: str):
    return re.findall(r"[a-z0-9]+", text.lower())


def _fnv1a32(data: bytes) -> int:
    h = 0x811C9DC5
    for byte in data:
        h ^= byte
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h


def _parse_tlm1(path: Path):
    """Parse the TLM1 container independently of the PHP implementation."""
    raw = path.read_bytes()
    assert len(raw) > 24, f"{path} is too short to be a TLM1 container"
    assert raw[:4] == b"TLM1", f"{path} does not start with the TLM1 magic"

    body, trailer = raw[:-4], raw[-4:]
    (checksum,) = struct.unpack("<I", trailer)
    assert checksum == _fnv1a32(body), f"{path} trailer checksum does not match its contents"

    version, class_count, vocab_size = struct.unpack_from("<HHI", raw, 4)
    (doc_total,) = struct.unpack_from("<Q", raw, 12)
    assert version == 3, f"{path} declares container version {version}, expected 3"
    assert class_count > 0 and vocab_size > 0, f"{path} declares an empty model"

    off = 20
    names, docs, token_totals = [], {}, {}
    for _ in range(class_count):
        length = raw[off]
        off += 1
        name = raw[off:off + length].decode("ascii")
        off += length
        doc_count, token_total = struct.unpack_from("<QQ", raw, off)
        off += 16
        names.append(name)
        docs[name] = doc_count
        token_totals[name] = token_total

    counts = {name: {} for name in names}
    tokens = []
    for _ in range(vocab_size):
        length = raw[off]
        off += 1
        token = raw[off:off + length]
        off += length
        values = struct.unpack_from("<" + "Q" * class_count, raw, off)
        off += 8 * class_count
        tokens.append(token)
        decoded = token.decode("ascii")
        for name, value in zip(names, values):
            if value:
                counts[name][decoded] = value

    assert off == len(raw) - 4, f"{path} has {len(raw) - 4 - off} unexpected trailing bytes"
    return {
        "names": names,
        "docs": docs,
        "token_totals": token_totals,
        "counts": counts,
        "vocab_size": vocab_size,
        "doc_total": doc_total,
        "tokens": tokens,
    }


def _predict(model, text: str) -> str:
    best, best_score = None, None
    for name in model["names"]:
        score = math.log(model["docs"][name] / model["doc_total"])
        denom = model["token_totals"][name] + model["vocab_size"]
        for token in _tokenize(text):
            score += math.log((model["counts"][name].get(token, 0) + 1) / denom)
        if best_score is None or score > best_score:
            best_score, best = score, name
    return best


def _f1_scores(gold, preds):
    tp = {c: 0 for c in CLASSES}
    fp = {c: 0 for c in CLASSES}
    fn = {c: 0 for c in CLASSES}
    for g, p in zip(gold, preds):
        if p == g:
            tp[g] += 1
        else:
            if p in fp:
                fp[p] += 1
            fn[g] += 1
    per = {}
    for c in CLASSES:
        prec = tp[c] / (tp[c] + fp[c]) if (tp[c] + fp[c]) else 0.0
        rec = tp[c] / (tp[c] + fn[c]) if (tp[c] + fn[c]) else 0.0
        per[c] = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    return sum(per.values()) / len(CLASSES), per


@pytest.fixture(scope="session")
def trained():
    """Queue an approved job at each revision, drain the queue, return the job rows."""
    jobs = {}
    for revision in REVISIONS:
        enq = _php([ENQUEUE, "sms_spam", revision])
        assert enq.returncode == 0, (
            f"enqueue of the approved corpus at revision {revision} failed: {enq.stderr}"
        )
        jobs[revision] = _job_id(enq.stdout)

    result = _php([WORKER])
    assert result.returncode == 0, f"worker failed: {result.stderr}"

    con = sqlite3.connect(str(DB))
    con.row_factory = sqlite3.Row
    rows = {}
    for revision, job_id in jobs.items():
        row = con.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        assert row is not None, f"job {job_id} is not in the queue database"
        job = dict(row)
        job["metrics_parsed"] = json.loads(job["metrics"]) if job["metrics"] else None
        rows[revision] = job
    con.close()
    return rows


@pytest.fixture(scope="session")
def current_model(trained):
    """Load the current revision's persisted model through an independent parser."""
    return _parse_tlm1(MODEL_DIR / f"r{CURRENT_REVISION}.bin")


def test_valid_dataset_is_queued():
    """The approved corpus at a defined revision is accepted and a job id comes back."""
    res = _php([ENQUEUE, "sms_spam", CURRENT_REVISION])
    assert res.returncode == 0, f"approved enqueue failed: {res.stderr}"
    assert _job_id(res.stdout) > 0


@pytest.mark.parametrize(
    "args",
    [
        ("file:///etc/passwd", "24"),
        ("../../etc/passwd", "24"),
        ("/etc/passwd", "24"),
        ("sms_spam.tsv", "24"),
        ("unknown_dataset", "24"),
        ("sms_spam", "25"),
        ("sms_spam", "-1"),
        ("sms_spam", "latest"),
    ],
)
def test_unapproved_submission_rejected(args):
    """Corpora outside the allowlist and revisions the policy does not define are refused."""
    res = _php([ENQUEUE, *args])
    assert res.returncode != 0, (
        f"submission {args!r} was accepted (exit 0); it must be refused"
    )


def test_worker_runs_to_completion(trained):
    """Each job reaches completed with progress 100 and the revision's model persisted."""
    for revision, job in trained.items():
        assert job["status"] == "completed", (
            f"revision {revision} job status was {job['status']!r}"
        )
        assert int(job["progress"]) == 100
        expected = MODEL_DIR / f"r{revision}.bin"
        assert job["model_path"] == str(expected), (
            f"revision {revision} recorded model_path {job['model_path']!r}, expected {expected}"
        )
        assert expected.is_file(), f"model not persisted at {expected}"


@pytest.mark.parametrize("revision", REVISIONS)
def test_derived_labels_match_policy(trained, revision):
    """Every corpus row's derived disposition matches the policy at that revision."""
    path = LABEL_DIR / f"{revision}.txt"
    assert path.is_file(), f"{path} was not written"
    actual = path.read_text().split()
    expected = _expected_labels(revision)
    assert len(actual) == len(expected), (
        f"{path} has {len(actual)} labels, expected {len(expected)}"
    )
    mismatches = [i for i, (a, e) in enumerate(zip(actual, expected)) if a != e]
    if mismatches:
        sample = ", ".join(
            f"row {i}: got {actual[i]!r} expected {expected[i]!r}" for i in mismatches[:5]
        )
        pytest.fail(
            f"revision {revision}: {len(mismatches)} of {len(expected)} derived "
            f"dispositions are wrong. {sample}"
        )


@pytest.mark.parametrize("revision", REVISIONS)
def test_label_counts_recorded(trained, revision):
    """Recorded class balance matches the policy-derived counts for that revision."""
    metrics = trained[revision]["metrics_parsed"]
    assert metrics is not None, f"revision {revision} job recorded no metrics"
    counts = metrics.get("label_counts")
    assert isinstance(counts, dict), "metrics.label_counts missing or not an object"
    expected = dict(Counter(_expected_labels(revision)))
    assert {k: int(v) for k, v in counts.items()} == expected, (
        f"revision {revision} label_counts {counts} do not match the policy "
        f"derivation {expected}"
    )


def test_worker_evaluates_trained_model(trained):
    """The worker records a held-out macro-F1 and per-disposition F1 for each job."""
    for revision, job in trained.items():
        metrics = job["metrics_parsed"]
        assert metrics is not None, f"revision {revision} job recorded no metrics"
        ev = metrics.get("evaluation")
        assert isinstance(ev, dict), f"revision {revision} metrics.evaluation missing"
        macro = ev.get("macro_f1")
        assert isinstance(macro, (int, float)) and 0.0 <= float(macro) <= 1.0, (
            f"revision {revision} metrics.evaluation.macro_f1 is not a valid score: {macro!r}"
        )
        per = ev.get("per_class")
        assert isinstance(per, dict) and set(CLASSES).issubset(per.keys()), (
            f"revision {revision} metrics.evaluation.per_class must cover all three dispositions"
        )
        for c in CLASSES:
            value = per[c]
            assert isinstance(value, (int, float)) and 0.0 <= float(value) <= 1.0, (
                f"revision {revision} per_class[{c}] is not a valid score: {value!r}"
            )


def test_persisted_models_conform_to_exchange_format(trained):
    """Both persisted models parse as TLM1 containers with the specified ordering."""
    for revision in REVISIONS:
        model = _parse_tlm1(MODEL_DIR / f"r{revision}.bin")
        assert sorted(model["names"]) == model["names"], (
            f"revision {revision} class table is not in ascending class-name order"
        )
        assert sorted(model["tokens"]) == model["tokens"], (
            f"revision {revision} vocabulary table is not in ascending token order"
        )
        assert set(model["names"]) == set(CLASSES), (
            f"revision {revision} model carries classes {model['names']}, expected the "
            f"three dispositions"
        )
        assert model["doc_total"] == sum(model["docs"].values()), (
            f"revision {revision} header document total disagrees with the class table"
        )


def test_persisted_model_serves_predictions(current_model, trained):
    """Inference run by this verifier from the persisted file alone clears the F1 floor."""
    probes = json.loads(PROBES.read_text())
    gold = [p["disposition"] for p in probes]
    preds = [_predict(current_model, p["text"]) for p in probes]
    macro, per = _f1_scores(gold, preds)
    assert macro >= MACRO_F1_THRESHOLD, (
        f"macro-F1 {macro:.4f} reconstructed from the persisted model is below the "
        f"{MACRO_F1_THRESHOLD} floor (per-class {({k: round(v, 4) for k, v in per.items()})})"
    )


def test_classify_serves_the_persisted_model(current_model, trained):
    """classify.php clears the F1 floor and agrees with the persisted model it serves."""
    probes = json.loads(PROBES.read_text())
    texts = [p["text"] for p in probes]
    gold = [p["disposition"] for p in probes]

    result = _php([CLASSIFY, CURRENT_REVISION], stdin="\n".join(texts) + "\n")
    assert result.returncode == 0, f"classify.php failed: {result.stderr}"
    preds = result.stdout.split("\n")
    while preds and preds[-1] == "":
        preds.pop()
    assert len(preds) == len(texts), (
        f"classify.php emitted {len(preds)} labels for {len(texts)} input lines"
    )

    macro, per = _f1_scores(gold, preds)
    assert macro >= MACRO_F1_THRESHOLD, (
        f"macro-F1 {macro:.4f} is below the {MACRO_F1_THRESHOLD} floor "
        f"(per-class {({k: round(v, 4) for k, v in per.items()})})"
    )

    reconstructed = [_predict(current_model, t) for t in texts]
    agreement = sum(a == b for a, b in zip(preds, reconstructed)) / len(texts)
    assert agreement >= AGREEMENT_THRESHOLD, (
        f"classify.php agrees with the persisted model on only {agreement:.2%} of probes; "
        f"it is not serving that file"
    )


def test_registry_dataset_unmodified():
    """The shipped corpus must not be altered by the agent."""
    digest = hashlib.sha256(DATASET.read_bytes()).hexdigest()
    assert digest == DATASET_SHA256, "the registry corpus was modified"
