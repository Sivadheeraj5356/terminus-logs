<?php

declare(strict_types=1);

namespace TrustLab;

final class DatasetResolver
{
    /**
     * @return array<int, array{0:string,1:string}> list of [gold, message]
     */
    public static function load(string $ref, string $registryDir): array
    {
        $path = rtrim($registryDir, '/') . '/datasets/' . $ref . '.tsv';
        $raw = file_get_contents($path);
        if ($raw === false) {
            throw new \RuntimeException("cannot read dataset: {$path}");
        }
        $rows = [];
        foreach (explode("\n", $raw) as $line) {
            $line = rtrim($line, "\r");
            if ($line === '') {
                continue;
            }
            $tab = strpos($line, "\t");
            if ($tab === false) {
                continue;
            }
            $rows[] = [substr($line, 0, $tab), substr($line, $tab + 1)];
        }
        return $rows;
    }
}
