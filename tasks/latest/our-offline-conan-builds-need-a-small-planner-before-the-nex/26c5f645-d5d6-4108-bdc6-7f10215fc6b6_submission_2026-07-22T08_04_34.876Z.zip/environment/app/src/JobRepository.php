<?php

declare(strict_types=1);

namespace TrustLab;

use PDO;

final class JobRepository
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    private function now(): string
    {
        return gmdate('Y-m-d\TH:i:s\Z');
    }

    public function enqueue(string $datasetRef): int
    {
        $now = $this->now();
        $stmt = $this->pdo->prepare(
            'INSERT INTO jobs (dataset_ref, status, progress, created_at, updated_at)
             VALUES (:ref, \'queued\', 0, :c, :u)'
        );
        $stmt->execute([':ref' => $datasetRef, ':c' => $now, ':u' => $now]);
        return (int) $this->pdo->lastInsertId();
    }

    public function claimNext(): ?array
    {
        $this->pdo->beginTransaction();
        try {
            $row = $this->pdo->query(
                'SELECT * FROM jobs WHERE status = \'queued\' ORDER BY id ASC LIMIT 1'
            )->fetch();
            if ($row === false) {
                $this->pdo->commit();
                return null;
            }
            $stmt = $this->pdo->prepare(
                'UPDATE jobs SET status = \'running\', progress = 5, updated_at = :u WHERE id = :id'
            );
            $stmt->execute([':u' => $this->now(), ':id' => $row['id']]);
            $this->pdo->commit();
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
        return $this->get((int) $row['id']);
    }

    public function setProgress(int $id, int $progress): void
    {
        $stmt = $this->pdo->prepare('UPDATE jobs SET progress = :p, updated_at = :u WHERE id = :id');
        $stmt->execute([':p' => $progress, ':u' => $this->now(), ':id' => $id]);
    }

    public function complete(int $id, string $modelPath, array $metrics): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE jobs SET status = \'completed\', progress = 100, model_path = :m,
             metrics = :met, error = NULL, updated_at = :u WHERE id = :id'
        );
        $stmt->execute([
            ':m' => $modelPath,
            ':met' => json_encode($metrics, JSON_UNESCAPED_SLASHES),
            ':u' => $this->now(),
            ':id' => $id,
        ]);
    }

    public function fail(int $id, string $error): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE jobs SET status = \'failed\', error = :e, updated_at = :u WHERE id = :id'
        );
        $stmt->execute([':e' => $error, ':u' => $this->now(), ':id' => $id]);
    }

    public function get(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM jobs WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }
}
