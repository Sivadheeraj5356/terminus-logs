<?php

declare(strict_types=1);

namespace TrustLab;

final class Classifier
{
    public static function tokenize(string $text): array
    {
        $text = strtolower($text);
        $parts = preg_split('/[^a-z0-9]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        return $parts === false ? [] : $parts;
    }

    /**
     * @param array<int, array{0:string,1:string}> $examples list of [text, label]
     */
    public static function train(array $examples): array
    {
        $classCounts = [];
        $wordCounts = [];
        $classTotals = [];
        $vocab = [];

        foreach ($examples as [$text, $label]) {
            $classCounts[$label] = ($classCounts[$label] ?? 0) + 1;
            foreach (self::tokenize($text) as $tok) {
                $vocab[$tok] = true;
                $wordCounts[$label][$tok] = ($wordCounts[$label][$tok] ?? 0) + 1;
                $classTotals[$label] = ($classTotals[$label] ?? 0) + 1;
            }
        }

        return [
            'classes' => $classCounts,
            'words' => $wordCounts,
            'class_totals' => $classTotals,
            'vocab_size' => count($vocab),
            'total' => array_sum($classCounts),
        ];
    }

    public static function save(array $model, string $path): void
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        file_put_contents($path, json_encode($model, JSON_UNESCAPED_SLASHES));
    }

    public static function load(string $path): array
    {
        $raw = file_get_contents($path);
        if ($raw === false) {
            throw new \RuntimeException("cannot read model: {$path}");
        }
        $model = json_decode($raw, true);
        if (!is_array($model)) {
            throw new \RuntimeException("invalid model json: {$path}");
        }
        return $model;
    }

    public static function predict(array $model, string $text): string
    {
        $classCounts = $model['classes'];
        $wordCounts = $model['words'];
        $classTotals = $model['class_totals'];
        $vocab = (int) $model['vocab_size'];
        $total = (int) $model['total'];

        $tokens = self::tokenize($text);
        $best = null;
        $bestScore = -INF;

        foreach ($classCounts as $label => $count) {
            $score = log($count / $total);
            $denom = ($classTotals[$label] ?? 0) + $vocab;
            foreach ($tokens as $tok) {
                $wc = $wordCounts[$label][$tok] ?? 0;
                $score += log(($wc + 1) / $denom);
            }
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $label;
            }
        }

        return (string) $best;
    }
}
