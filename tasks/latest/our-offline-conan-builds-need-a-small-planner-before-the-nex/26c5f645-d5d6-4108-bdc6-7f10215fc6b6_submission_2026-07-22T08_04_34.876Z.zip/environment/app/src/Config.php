<?php

declare(strict_types=1);

namespace TrustLab;

final class Config
{
    private array $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public static function load(string $path = '/app/config/pipeline.json'): self
    {
        $raw = file_get_contents($path);
        if ($raw === false) {
            throw new \RuntimeException("cannot read config: {$path}");
        }
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            throw new \RuntimeException("invalid config json: {$path}");
        }
        return new self($data);
    }

    public function approvedDatasets(): array
    {
        return array_values($this->data['approved_datasets'] ?? []);
    }

    public function registryDir(): string
    {
        return (string) ($this->data['registry_dir'] ?? '/app/registry');
    }

    public function databasePath(): string
    {
        return (string) ($this->data['database_path'] ?? '/app/data/queue.db');
    }

    public function modelDir(): string
    {
        return (string) ($this->data['model_dir'] ?? '/app/models');
    }
}
