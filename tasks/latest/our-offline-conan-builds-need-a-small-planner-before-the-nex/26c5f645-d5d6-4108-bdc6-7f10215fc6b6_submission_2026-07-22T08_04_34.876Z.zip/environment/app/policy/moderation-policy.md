# Messaging Trust and Safety Moderation Policy Dossier

Document reference: TSP-MOD-DOSSIER. Classification: Internal. Applies to all automated and human review of short message traffic ingested by the platform moderation pipeline.

This dossier is the controlling reference for how inbound message traffic is dispositioned. It defines the disposition taxonomy, the registers that drive escalation, the amendment record that keeps those registers current, the derivation of training labels for moderation models, and the normalization rules that make every derivation reproducible. Where a numbered clause conflicts with an appendix, the numbered clause governs.

| Version | Date | Author | Summary |
|---|---|---|---|
| 3.1 | 2018-06-08 | A. Okonkwo | Revision of clauses 4 to 9; registers reconciled. |
| 3.2 | 2018-11-15 | M. Halvorsen | Revision of clauses 7 to 12; registers reconciled. |
| 3.3 | 2019-04-22 | P. Ramaswamy | Revision of clauses 10 to 15; registers reconciled. |
| 3.4 | 2019-09-02 | L. Chen | Revision of clauses 13 to 18; registers reconciled. |
| 3.5 | 2019-02-09 | S. Adebayo | Revision of clauses 16 to 21; registers reconciled. |
| 3.6 | 2020-07-16 | R. Fitzgerald | Revision of clauses 19 to 24; registers reconciled. |
| 3.7 | 2020-12-23 | N. Okafor | Revision of clauses 22 to 27; registers reconciled. |
| 3.8 | 2020-05-03 | T. Villanueva | Revision of clauses 25 to 30; registers reconciled. |
| 3.9 | 2021-10-10 | A. Okonkwo | Revision of clauses 28 to 33; registers reconciled. |
| 3.10 | 2021-03-17 | M. Halvorsen | Revision of clauses 31 to 36; registers reconciled. |
| 3.11 | 2021-08-24 | P. Ramaswamy | Revision of clauses 34 to 39; registers reconciled. |
| 3.12 | 2022-01-04 | L. Chen | Revision of clauses 37 to 42; registers reconciled. |
| 3.13 | 2022-06-11 | S. Adebayo | Revision of clauses 40 to 45; registers reconciled. |
| 3.14 | 2022-11-18 | R. Fitzgerald | Revision of clauses 3 to 8; registers reconciled. |
| 3.15 | 2023-04-25 | N. Okafor | Revision of clauses 6 to 11; registers reconciled. |
| 3.16 | 2023-09-05 | T. Villanueva | Revision of clauses 9 to 14; registers reconciled. |

## 1. Purpose and Scope

The moderation service protects recipients from unsolicited and deceptive traffic while preserving delivery of legitimate personal and transactional messages. The policy balances under-blocking, where harmful traffic reaches recipients, against over-blocking, where legitimate traffic is suppressed. The taxonomy in Section 4 and the cascade in Section 5 exist so the pipeline is never forced into a binary choice for traffic that is suspicious but plausibly legitimate.

Scope covers all ingested traffic classes and, importantly, the derivation of training labels for the models that score that traffic. Divergence between the labels used at training time and the dispositions used at serving time is the single most common source of production incidents, so the derivation is specified here rather than left to implementations.

An implementation is conformant only if the disposition it derives for a message is identical to the one a careful reviewer would derive by applying Sections 4 through 6 together with the effective registers defined in Section 8. Conformance is assessed against outcomes, not structure.

## 2. Governance and Change Control

The Trust and Safety Policy Board owns this dossier. Changes to numbered clauses require a two-thirds majority and a recorded rationale. Changes to either escalation register are made only by numbered amendment recorded in Section 8, because register membership directly determines how much traffic is escalated and therefore carries staffing and cost implications.

Amendments are never applied retroactively to the printed appendices. The appendices record the registers as adopted at version 3.0 and are deliberately left unedited so that the amendment trail stays auditable. This is a documentation convention with an operational consequence described in Section 8: the printed appendix is not, by itself, the register an implementation should use.

## 3. Definitions

- **Disposition**: the moderation outcome assigned to a message, drawn from the controlled vocabulary in Section 4.
- **Gold label**: the coarse two-valued label carried by a reference corpus, either `ham` or `spam`. A gold label is an input to derivation and is never itself a disposition.
- **Register**: a controlled list of tokens maintained by this dossier. Two registers drive dispositions: the high-risk register and the safe-harbour register.
- **Base register**: the register contents as printed in the appendices, that is, as adopted at version 3.0.
- **Effective register**: the base register after every amendment in Section 8 has been applied in the order listed. The effective register is what an implementation must use.
- **High-risk token**: a token present in the effective high-risk register.
- **Safe-harbour token**: a token present in the effective safe-harbour register, indicating genuine transactional context.
- **Distinct count**: the number of different register tokens present in a message, counting each token type once no matter how many times it occurs.
- **Commercial token**: a token in the informational register at Appendix G. Commercial tokens never affect a disposition.
- **Normalization**: the deterministic transformation of raw text into a token sequence, defined in Section 6.

## 4. Disposition Taxonomy

Every message receives exactly one disposition. The vocabulary is closed and written in lower case: `allow`, `quarantine`, and `block`. No other value is valid. The gold labels `ham` and `spam` are not dispositions and must never be emitted as such.

`allow` means the message is delivered. `block` means it is suppressed and not delivered. `quarantine` means it is withheld and placed in the human review queue.

Quarantine is not a stronger form of blocking. It is a routing decision that sends a message to a human because an automated terminal decision is unsafe in either direction.

## 5. Disposition Cascade

For each message compute two counts over the normalized token sequence defined in Section 6, using the effective registers from Section 8:

- `h`, the **distinct** number of high-risk register tokens present in the message.
- `s`, the **distinct** number of safe-harbour register tokens present in the message.

Then apply the following clauses **in order** and take the disposition of the first clause that matches.

1. If `h` is 2 or more, the disposition is `block`.
2. Otherwise, if `h` is 1 or more and `s` is 1 or more, the disposition is `allow`.
3. Otherwise, if the gold label is `spam` and `h` is exactly 1, the disposition is `quarantine`.
4. Otherwise, if the gold label is `spam` and `h` is 0, the disposition is `block`.
5. Otherwise the disposition is `allow`.

The commercial register at Appendix G takes no part in this cascade.

## 6. Normalization, Matching, and Counting

Matching is performed on a normalized token sequence, never on the raw string. Normalization is deterministic: lower-case the text over the ASCII range, split it on every maximal run of characters that are not ASCII letters or digits, and discard empty tokens. The result is a sequence of tokens drawn from the characters a to z and 0 to 9.

A register token is present if and only if some token in the normalized sequence is exactly equal to that register entry under whole-token string comparison. Substring, prefix, stem, and edit-distance matching are not used.

Both `h` and `s` are counts of **distinct** register entries, not counts of occurrences.

## 7. Risk Model and Rationale

The asymmetry in Section 5 follows from the harm model. Deceptive traffic imitates transactional traffic, so a single risk term cannot support a confident automated block: the false-positive cost of suppressing a genuine passcode or fraud alert is high and immediate. That is the ambiguous band, and it goes to review.

Two or more independent risk terms in the same short message is a different matter. Genuine transactional messages are narrow and rarely stack unrelated risk vocabulary, so the accumulation is itself the signal, and clause 1 suppresses it without review. The safe-harbour register exists for the opposite reason: a transactional marker is strong evidence that a flagged message is a real notice that the upstream classifier misread, so clause 2 releases it.

Attempts to simplify the cascade to a binary allow-or-block decision have been rejected by the Board on three recorded occasions, each after an incident in which a binary rule suppressed a surge of legitimate one-time passcodes.

## 8. Register Amendments

The appendices print the registers **as adopted at version 3.0**. They are not maintained in place. Every subsequent change is recorded as a numbered amendment in the table below. The amendments are listed in amendment-number order, which is not the order in which they take effect.

The effective register is obtained by replaying the amendment stream over the base registers under the following rules.

Ordering. Amendments take effect in ascending order of their **Effective date**, not in amendment-number order. Where two amendments share an effective date, the lower amendment number takes effect first. The amendment-number order in the table is a filing order only.

Corrections. A `void` amendment is a correction: it names an earlier amendment, and both the named amendment and the `void` itself are struck from the stream and contribute nothing to the register. A `void` names an amendment whose effective date precedes its own.

Conditional amendments. A `cond` amendment carries a condition and two branches. At the moment it takes effect, evaluate the condition against the register state produced by every earlier-effective amendment already applied, then apply the branch the condition selects. The condition is read against the state at that moment, not against the final register.

Actions. `add` places a token in the named register. `remove` deletes a token from the named register. `move` deletes a token from the source register and places it in the target register. A branch of a `cond` is itself one of these actions, or `no change`.

Revisions. The register is versioned by **policy revision**. Order the amendments by effective date (ties by amendment number); policy revision `R` is the base register with the first `R` amendments in that order replayed, and none after. Revision 0 is the base appendix contents exactly as printed, and the highest revision is the current effective register. Corrections and conditions are resolved within the first `R` amendments only: a `void` whose named amendment falls outside the first `R` has no one to strike, and a `cond` reads the state built from the amendments inside the first `R`. A disposition is meaningful only with respect to a stated revision, and adjudications, appeals, and retraining runs each name the revision they were computed under.

| Amendment | Effective date | Action |
|---|---|---|
| AMD-001 | 2024-02-05 | Remove `free` from the high-risk register. |
| AMD-002 | 2024-01-16 | Add `payid` to the high-risk register. |
| AMD-003 | 2024-04-02 | Add `seizure` to the high-risk register. |
| AMD-004 | 2024-02-27 | Add `hold` to the high-risk register. |
| AMD-005 | 2024-03-11 | Move `refund` from the high-risk register to the safe-harbour register. |
| AMD-006 | 2024-06-25 | Add `jackpot` to the high-risk register. |
| AMD-007 | 2024-04-23 | Remove `cash` from the high-risk register. |
| AMD-008 | 2024-05-14 | Add `confirmation` to the safe-harbour register. |
| AMD-009 | 2024-06-03 | Remove `notice` from the safe-harbour register. |
| AMD-010 | 2024-11-18 | Void AMD-006. |
| AMD-011 | 2024-07-15 | If `hold` is in the high-risk register, remove `hold` from the high-risk register; otherwise no change. |
| AMD-012 | 2024-08-06 | Move `credited` from the high-risk register to the safe-harbour register. |
| AMD-013 | 2024-09-02 | Remove `reward` from the high-risk register. |
| AMD-014 | 2024-09-24 | Add `checkin` to the safe-harbour register. |
| AMD-015 | 2024-10-14 | Remove `debited` from the high-risk register. |
| AMD-016 | 2024-05-02 | Add `bonus` to the high-risk register. |
| AMD-017 | 2024-12-09 | Void AMD-016. |
| AMD-018 | 2024-10-30 | Add `forfeit` to the high-risk register. |
| AMD-019 | 2025-01-13 | If `confirmation` is in the safe-harbour register, add `rebate` to the safe-harbour register; otherwise add `rebate` to the high-risk register. |
| AMD-020 | 2025-02-10 | Remove `topup` from the high-risk register. |
| AMD-021 | 2024-07-29 | Add `wire` to the high-risk register. |
| AMD-022 | 2025-03-04 | Move `wire` from the high-risk register to the safe-harbour register. |
| AMD-023 | 2024-08-20 | Add `escrow` to the high-risk register. |
| AMD-024 | 2025-03-25 | Void AMD-023. |

The Board publishes no consolidated reprint of the register at any revision. The amendment stream is the single source of truth.

## 9. Operating Procedure and Service Levels

Traffic dispositioned `allow` is delivered immediately. Traffic dispositioned `block` is suppressed immediately; a suppression notice is sent only where regulation requires one. Traffic dispositioned `quarantine` enters the human review queue under the service levels below.

| Sender class | Queue priority | First-touch target | Resolution target | Escalation trigger |
|---|---|---|---|---|
| Transactional sender | 1 | 5 minutes | 30 minutes | missed first-touch |
| Bulk application sender | 2 | 15 minutes | 2 hours | queue depth over 500 |
| Personal handset | 3 | 30 minutes | 4 hours | reviewer disagreement |
| International gateway | 4 | 45 minutes | 6 hours | repeat sender |
| Unregistered short code | 5 | 10 minutes | 1 hour | regulatory hold |
| Aggregator route | 6 | 20 minutes | 3 hours | legal flag |

A reviewer may release a quarantined message, which converts the outcome to `allow`, or confirm it, which converts the outcome to `block`, or hold it for a second reviewer. Reviewers may not invent outcomes outside the Section 4 vocabulary. Because clause 1 of the cascade suppresses multi-signal traffic without review, queue volume is driven almost entirely by the single-risk-signal band in clause 3, and register amendments that add tokens therefore raise queue volume roughly linearly.

## 10. Appeals and Remediation

A sender whose traffic is dispositioned `block` may appeal within thirty days. Appeals are assessed against the same clauses that produced the original disposition. An appeal succeeds only if the original disposition was inconsistent with Sections 4 through 6 applied to the message as sent, using the effective registers current at the time of sending.

Where an appeal reveals that an implementation derived a disposition inconsistent with the policy, the finding is raised as an implementation defect. The policy is not amended to match an incorrect implementation.

## 11. Retention, Audit, and Privacy

Dispositions, the register tokens that drove them, and reviewer actions are retained for twenty-four months. Message content is minimised in logs; only the matched register tokens are recorded against a message except where it is held for review.

Audit recomputes the derived disposition for each sampled message directly from Sections 4 through 6 and the effective registers, then compares it to what the pipeline emitted. Because the derivation is deterministic, a correct implementation produces zero discrepancies. A non-zero discrepancy rate is treated as evidence that the implementation has diverged, most often on the distinct-count rule or on register currency.

## 12. Jurisdictional Annex

The taxonomy, the cascade, and the registers are uniform across jurisdictions. What varies is the notice obligation on suppression, the retention ceiling, and quiet-hour handling. None of these alters `h`, `s`, or the clause that fires.

**12.1 Northlands Union.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.2 Cape Meridian.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.3 Eastern Littoral.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.4 Sundari Federation.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.5 Highvale Cantons.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.6 Auralis Republic.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.7 Karst Provinces.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.8 Meridian Isles.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.9 Boreal Commonwealth.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.10 Talmerind.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.11 Verdant Reach.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.12 Solenne Districts.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.13 Ambercoast.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.14 Ferran States.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.15 Lowmarch Union.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.16 Cindralia.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.17 Petrichor Belt.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.18 Windward Territories.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.19 Grey Harbour.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.20 Oster Basin.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.21 Novagrad.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.22 Serrano Confederacy.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.23 Aldermere.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.24 Thornfield Provinces.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.25 Uplands Accord.** Suppression of `block` traffic requires a suppression notice within 24 hours. The retention ceiling for review artefacts is 12 months. Regulated quiet hours are 21:00 to 08:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.26 Marisol Coast.** Suppression of `block` traffic requires no suppression notice. The retention ceiling for review artefacts is 18 months. Regulated quiet hours are 22:00 to 07:00 local; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.27 Halden Reach.** Suppression of `block` traffic requires a suppression notice on request only. The retention ceiling for review artefacts is 24 months. Regulated quiet hours are no quiet hours; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

**12.28 Verrell Union.** Suppression of `block` traffic requires a monthly aggregate report. The retention ceiling for review artefacts is 36 months. Regulated quiet hours are 20:00 to 09:00 local for promotional traffic only; during quiet hours a message that clause 3 sends to `quarantine` is still queued and reviewed, but release is deferred until quiet hours end unless the sender class is transactional. Traffic suppressed by clause 1 is not deferred, because no review step is pending.

## 13. Adjudicated Example Bank

Worked examples. Each records a paraphrased message, its gold label, the distinct high-risk and safe-harbour tokens found under the effective registers, the clause that fires, and the disposition. Messages are illustrative paraphrases and are not drawn from any corpus.

**Case EX-0001.** From an unregistered short code: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0002.** From a verified bank sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0003.** From a personal handset: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0004.** From a bulk marketing gateway: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0005.** From an international number: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0006.** From a retail loyalty programme: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0007.** From a logistics tracking sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0008.** From a utility provider: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0009.** From an aggregator route: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0010.** From a two-factor delivery sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0011.** From a payment processor alias: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0012.** From a government notices line: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0013.** From an unregistered short code: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0014.** From a verified bank sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0015.** From a personal handset: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0016.** From a bulk marketing gateway: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0017.** From an international number: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0018.** From a retail loyalty programme: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0019.** From a logistics tracking sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0020.** From a utility provider: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0021.** From an aggregator route: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0022.** From a two-factor delivery sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0023.** From a payment processor alias: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0024.** From a government notices line: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0025.** From an unregistered short code: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0026.** From a verified bank sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0027.** From a personal handset: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0028.** From a bulk marketing gateway: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0029.** From an international number: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0030.** From a retail loyalty programme: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0031.** From a logistics tracking sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0032.** From a utility provider: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0033.** From an aggregator route: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0034.** From a two-factor delivery sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0035.** From a payment processor alias: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0036.** From a government notices line: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0037.** From an unregistered short code: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0038.** From a verified bank sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0039.** From a personal handset: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0040.** From a bulk marketing gateway: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0041.** From an international number: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0042.** From a retail loyalty programme: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0043.** From a logistics tracking sender: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0044.** From a utility provider: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0045.** From an aggregator route: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0046.** From a two-factor delivery sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0047.** From a payment processor alias: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0048.** From a government notices line: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0049.** From an unregistered short code: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0050.** From a verified bank sender: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0051.** From a personal handset: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0052.** From a bulk marketing gateway: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0053.** From an international number: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0054.** From a retail loyalty programme: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0055.** From a logistics tracking sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0056.** From a utility provider: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0057.** From an aggregator route: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0058.** From a two-factor delivery sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0059.** From a payment processor alias: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0060.** From a government notices line: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0061.** From an unregistered short code: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0062.** From a verified bank sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0063.** From a personal handset: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0064.** From a bulk marketing gateway: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0065.** From an international number: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0066.** From a retail loyalty programme: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0067.** From a logistics tracking sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0068.** From a utility provider: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0069.** From an aggregator route: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0070.** From a two-factor delivery sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0071.** From a payment processor alias: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0072.** From a government notices line: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0073.** From an unregistered short code: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0074.** From a verified bank sender: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0075.** From a personal handset: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0076.** From a bulk marketing gateway: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0077.** From an international number: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0078.** From a retail loyalty programme: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0079.** From a logistics tracking sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0080.** From a utility provider: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0081.** From an aggregator route: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0082.** From a two-factor delivery sender: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0083.** From a payment processor alias: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0084.** From a government notices line: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0085.** From an unregistered short code: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0086.** From a verified bank sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0087.** From a personal handset: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0088.** From a bulk marketing gateway: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0089.** From an international number: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0090.** From a retail loyalty programme: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0091.** From a logistics tracking sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0092.** From a utility provider: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0093.** From an aggregator route: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0094.** From a two-factor delivery sender: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0095.** From a payment processor alias: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0096.** From a government notices line: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0097.** From an unregistered short code: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0098.** From a verified bank sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0099.** From a personal handset: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0100.** From a bulk marketing gateway: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0101.** From an international number: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0102.** From a retail loyalty programme: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0103.** From a logistics tracking sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0104.** From a utility provider: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0105.** From an aggregator route: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0106.** From a two-factor delivery sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0107.** From a payment processor alias: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0108.** From a government notices line: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0109.** From an unregistered short code: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0110.** From a verified bank sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0111.** From a personal handset: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0112.** From a bulk marketing gateway: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0113.** From an international number: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0114.** From a retail loyalty programme: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0115.** From a logistics tracking sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0116.** From a utility provider: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0117.** From an aggregator route: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0118.** From a two-factor delivery sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0119.** From a payment processor alias: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0120.** From a government notices line: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0121.** From an unregistered short code: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0122.** From a verified bank sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0123.** From a personal handset: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0124.** From a bulk marketing gateway: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0125.** From an international number: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0126.** From a retail loyalty programme: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0127.** From a logistics tracking sender: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0128.** From a utility provider: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0129.** From an aggregator route: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0130.** From a two-factor delivery sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0131.** From a payment processor alias: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0132.** From a government notices line: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0133.** From an unregistered short code: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0134.** From a verified bank sender: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0135.** From a personal handset: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0136.** From a bulk marketing gateway: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0137.** From an international number: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0138.** From a retail loyalty programme: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0139.** From a logistics tracking sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0140.** From a utility provider: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0141.** From an aggregator route: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0142.** From a two-factor delivery sender: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0143.** From a payment processor alias: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0144.** From a government notices line: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0145.** From an unregistered short code: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0146.** From a verified bank sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0147.** From a personal handset: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0148.** From a bulk marketing gateway: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0149.** From an international number: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0150.** From a retail loyalty programme: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0151.** From a logistics tracking sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0152.** From a utility provider: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0153.** From an aggregator route: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0154.** From a two-factor delivery sender: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0155.** From a payment processor alias: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0156.** From a government notices line: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0157.** From an unregistered short code: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0158.** From a verified bank sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0159.** From a personal handset: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0160.** From a bulk marketing gateway: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0161.** From an international number: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0162.** From a retail loyalty programme: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0163.** From a logistics tracking sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0164.** From a utility provider: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0165.** From an aggregator route: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0166.** From a two-factor delivery sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0167.** From a payment processor alias: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0168.** From a government notices line: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0169.** From an unregistered short code: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0170.** From a verified bank sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0171.** From a personal handset: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0172.** From a bulk marketing gateway: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0173.** From an international number: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0174.** From a retail loyalty programme: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0175.** From a logistics tracking sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0176.** From a utility provider: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0177.** From an aggregator route: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0178.** From a two-factor delivery sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0179.** From a payment processor alias: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0180.** From a government notices line: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0181.** From an unregistered short code: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0182.** From a verified bank sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0183.** From a personal handset: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0184.** From a bulk marketing gateway: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0185.** From an international number: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0186.** From a retail loyalty programme: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0187.** From a logistics tracking sender: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0188.** From a utility provider: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0189.** From an aggregator route: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0190.** From a two-factor delivery sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0191.** From a payment processor alias: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0192.** From a government notices line: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0193.** From an unregistered short code: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0194.** From a verified bank sender: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0195.** From a personal handset: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0196.** From a bulk marketing gateway: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0197.** From an international number: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0198.** From a retail loyalty programme: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0199.** From a logistics tracking sender: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0200.** From a utility provider: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0201.** From an aggregator route: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0202.** From a two-factor delivery sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0203.** From a payment processor alias: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0204.** From a government notices line: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0205.** From an unregistered short code: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0206.** From a verified bank sender: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0207.** From a personal handset: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0208.** From a bulk marketing gateway: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0209.** From an international number: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0210.** From a retail loyalty programme: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0211.** From a logistics tracking sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0212.** From a utility provider: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0213.** From an aggregator route: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0214.** From a two-factor delivery sender: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0215.** From a payment processor alias: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0216.** From a government notices line: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0217.** From an unregistered short code: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0218.** From a verified bank sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0219.** From a personal handset: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0220.** From a bulk marketing gateway: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0221.** From an international number: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0222.** From a retail loyalty programme: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0223.** From a logistics tracking sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0224.** From a utility provider: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0225.** From an aggregator route: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0226.** From a two-factor delivery sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0227.** From a payment processor alias: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0228.** From a government notices line: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0229.** From an unregistered short code: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0230.** From a verified bank sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0231.** From a personal handset: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0232.** From a bulk marketing gateway: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0233.** From an international number: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0234.** From a retail loyalty programme: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0235.** From a logistics tracking sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0236.** From a utility provider: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0237.** From an aggregator route: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0238.** From a two-factor delivery sender: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0239.** From a payment processor alias: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0240.** From a government notices line: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0241.** From an unregistered short code: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0242.** From a verified bank sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0243.** From a personal handset: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0244.** From a bulk marketing gateway: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0245.** From an international number: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0246.** From a retail loyalty programme: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0247.** From a logistics tracking sender: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0248.** From a utility provider: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0249.** From an aggregator route: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0250.** From a two-factor delivery sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0251.** From a payment processor alias: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0252.** From a government notices line: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0253.** From an unregistered short code: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0254.** From a verified bank sender: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0255.** From a personal handset: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0256.** From a bulk marketing gateway: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0257.** From an international number: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0258.** From a retail loyalty programme: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0259.** From a logistics tracking sender: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0260.** From a utility provider: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0261.** From an aggregator route: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0262.** From a two-factor delivery sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0263.** From a payment processor alias: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0264.** From a government notices line: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0265.** From an unregistered short code: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0266.** From a verified bank sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0267.** From a personal handset: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0268.** From a bulk marketing gateway: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0269.** From an international number: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0270.** From a retail loyalty programme: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0271.** From a logistics tracking sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0272.** From a utility provider: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0273.** From an aggregator route: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0274.** From a two-factor delivery sender: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0275.** From a payment processor alias: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0276.** From a government notices line: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0277.** From an unregistered short code: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0278.** From a verified bank sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0279.** From a personal handset: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0280.** From a bulk marketing gateway: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0281.** From an international number: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0282.** From a retail loyalty programme: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0283.** From a logistics tracking sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0284.** From a utility provider: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0285.** From an aggregator route: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0286.** From a two-factor delivery sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0287.** From a payment processor alias: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0288.** From a government notices line: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0289.** From an unregistered short code: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0290.** From a verified bank sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0291.** From a personal handset: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0292.** From a bulk marketing gateway: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0293.** From an international number: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0294.** From a retail loyalty programme: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0295.** From a logistics tracking sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0296.** From a utility provider: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0297.** From an aggregator route: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0298.** From a two-factor delivery sender: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0299.** From a payment processor alias: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0300.** From a government notices line: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0301.** From an unregistered short code: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0302.** From a verified bank sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0303.** From a personal handset: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0304.** From a bulk marketing gateway: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0305.** From an international number: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0306.** From a retail loyalty programme: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0307.** From a logistics tracking sender: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0308.** From a utility provider: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0309.** From an aggregator route: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0310.** From a two-factor delivery sender: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0311.** From a payment processor alias: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0312.** From a government notices line: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0313.** From an unregistered short code: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0314.** From a verified bank sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0315.** From a personal handset: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0316.** From a bulk marketing gateway: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0317.** From an international number: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0318.** From a retail loyalty programme: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0319.** From a logistics tracking sender: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0320.** From a utility provider: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0321.** From an aggregator route: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0322.** From a two-factor delivery sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0323.** From a payment processor alias: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0324.** From a government notices line: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0325.** From an unregistered short code: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0326.** From a verified bank sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0327.** From a personal handset: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0328.** From a bulk marketing gateway: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0329.** From an international number: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0330.** From a retail loyalty programme: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0331.** From a logistics tracking sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0332.** From a utility provider: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0333.** From an aggregator route: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0334.** From a two-factor delivery sender: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0335.** From a payment processor alias: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0336.** From a government notices line: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0337.** From an unregistered short code: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0338.** From a verified bank sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0339.** From a personal handset: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0340.** From a bulk marketing gateway: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0341.** From an international number: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0342.** From a retail loyalty programme: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0343.** From a logistics tracking sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0344.** From a utility provider: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0345.** From an aggregator route: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0346.** From a two-factor delivery sender: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0347.** From a payment processor alias: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0348.** From a government notices line: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0349.** From an unregistered short code: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0350.** From a verified bank sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0351.** From a personal handset: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0352.** From a bulk marketing gateway: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0353.** From an international number: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0354.** From a retail loyalty programme: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0355.** From a logistics tracking sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0356.** From a utility provider: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0357.** From an aggregator route: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0358.** From a two-factor delivery sender: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0359.** From a payment processor alias: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0360.** From a government notices line: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0361.** From an unregistered short code: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0362.** From a verified bank sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0363.** From a personal handset: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0364.** From a bulk marketing gateway: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0365.** From an international number: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0366.** From a retail loyalty programme: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0367.** From a logistics tracking sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0368.** From a utility provider: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0369.** From an aggregator route: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0370.** From a two-factor delivery sender: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0371.** From a payment processor alias: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0372.** From a government notices line: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0373.** From an unregistered short code: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0374.** From a verified bank sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0375.** From a personal handset: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0376.** From a bulk marketing gateway: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0377.** From an international number: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0378.** From a retail loyalty programme: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0379.** From a logistics tracking sender: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0380.** From a utility provider: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0381.** From an aggregator route: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0382.** From a two-factor delivery sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0383.** From a payment processor alias: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0384.** From a government notices line: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0385.** From an unregistered short code: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0386.** From a verified bank sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0387.** From a personal handset: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0388.** From a bulk marketing gateway: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0389.** From an international number: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0390.** From a retail loyalty programme: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0391.** From a logistics tracking sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0392.** From a utility provider: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0393.** From an aggregator route: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0394.** From a two-factor delivery sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0395.** From a payment processor alias: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0396.** From a government notices line: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0397.** From an unregistered short code: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0398.** From a verified bank sender: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0399.** From a personal handset: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0400.** From a bulk marketing gateway: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0401.** From an international number: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0402.** From a retail loyalty programme: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0403.** From a logistics tracking sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0404.** From a utility provider: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0405.** From an aggregator route: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0406.** From a two-factor delivery sender: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0407.** From a payment processor alias: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0408.** From a government notices line: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0409.** From an unregistered short code: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0410.** From a verified bank sender: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0411.** From a personal handset: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0412.** From a bulk marketing gateway: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0413.** From an international number: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0414.** From a retail loyalty programme: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0415.** From a logistics tracking sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0416.** From a utility provider: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0417.** From an aggregator route: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0418.** From a two-factor delivery sender: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0419.** From a payment processor alias: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0420.** From a government notices line: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0421.** From an unregistered short code: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0422.** From a verified bank sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0423.** From a personal handset: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0424.** From a bulk marketing gateway: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0425.** From an international number: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0426.** From a retail loyalty programme: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0427.** From a logistics tracking sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0428.** From a utility provider: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0429.** From an aggregator route: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0430.** From a two-factor delivery sender: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0431.** From a payment processor alias: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0432.** From a government notices line: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0433.** From an unregistered short code: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0434.** From a verified bank sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0435.** From a personal handset: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0436.** From a bulk marketing gateway: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0437.** From an international number: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0438.** From a retail loyalty programme: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0439.** From a logistics tracking sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0440.** From a utility provider: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0441.** From an aggregator route: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0442.** From a two-factor delivery sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0443.** From a payment processor alias: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0444.** From a government notices line: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0445.** From an unregistered short code: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0446.** From a verified bank sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0447.** From a personal handset: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0448.** From a bulk marketing gateway: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0449.** From an international number: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0450.** From a retail loyalty programme: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0451.** From a logistics tracking sender: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0452.** From a utility provider: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0453.** From an aggregator route: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0454.** From a two-factor delivery sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0455.** From a payment processor alias: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0456.** From a government notices line: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0457.** From an unregistered short code: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0458.** From a verified bank sender: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0459.** From a personal handset: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0460.** From a bulk marketing gateway: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0461.** From an international number: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0462.** From a retail loyalty programme: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0463.** From a logistics tracking sender: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0464.** From a utility provider: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0465.** From an aggregator route: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0466.** From a two-factor delivery sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0467.** From a payment processor alias: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0468.** From a government notices line: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0469.** From an unregistered short code: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0470.** From a verified bank sender: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0471.** From a personal handset: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0472.** From a bulk marketing gateway: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0473.** From an international number: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0474.** From a retail loyalty programme: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0475.** From a logistics tracking sender: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0476.** From a utility provider: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0477.** From an aggregator route: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0478.** From a two-factor delivery sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0479.** From a payment processor alias: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0480.** From a government notices line: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0481.** From an unregistered short code: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0482.** From a verified bank sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0483.** From a personal handset: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0484.** From a bulk marketing gateway: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0485.** From an international number: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0486.** From a retail loyalty programme: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0487.** From a logistics tracking sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0488.** From a utility provider: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0489.** From an aggregator route: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0490.** From a two-factor delivery sender: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0491.** From a payment processor alias: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0492.** From a government notices line: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0493.** From an unregistered short code: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0494.** From a verified bank sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0495.** From a personal handset: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0496.** From a bulk marketing gateway: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0497.** From an international number: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0498.** From a retail loyalty programme: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0499.** From a logistics tracking sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0500.** From a utility provider: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0501.** From an aggregator route: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0502.** From a two-factor delivery sender: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0503.** From a payment processor alias: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0504.** From a government notices line: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0505.** From an unregistered short code: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0506.** From a verified bank sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0507.** From a personal handset: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0508.** From a bulk marketing gateway: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0509.** From an international number: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0510.** From a retail loyalty programme: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0511.** From a logistics tracking sender: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0512.** From a utility provider: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0513.** From an aggregator route: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0514.** From a two-factor delivery sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0515.** From a payment processor alias: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0516.** From a government notices line: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0517.** From an unregistered short code: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0518.** From a verified bank sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0519.** From a personal handset: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0520.** From a bulk marketing gateway: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0521.** From an international number: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0522.** From a retail loyalty programme: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0523.** From a logistics tracking sender: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0524.** From a utility provider: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0525.** From an aggregator route: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0526.** From a two-factor delivery sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0527.** From a payment processor alias: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0528.** From a government notices line: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0529.** From an unregistered short code: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0530.** From a verified bank sender: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0531.** From a personal handset: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0532.** From a bulk marketing gateway: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0533.** From an international number: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0534.** From a retail loyalty programme: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0535.** From a logistics tracking sender: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0536.** From a utility provider: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0537.** From an aggregator route: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0538.** From a two-factor delivery sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0539.** From a payment processor alias: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0540.** From a government notices line: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0541.** From an unregistered short code: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0542.** From a verified bank sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0543.** From a personal handset: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0544.** From a bulk marketing gateway: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0545.** From an international number: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0546.** From a retail loyalty programme: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0547.** From a logistics tracking sender: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0548.** From a utility provider: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0549.** From an aggregator route: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0550.** From a two-factor delivery sender: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0551.** From a payment processor alias: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0552.** From a government notices line: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0553.** From an unregistered short code: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0554.** From a verified bank sender: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0555.** From a personal handset: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0556.** From a bulk marketing gateway: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0557.** From an international number: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0558.** From a retail loyalty programme: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0559.** From a logistics tracking sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0560.** From a utility provider: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0561.** From an aggregator route: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0562.** From a two-factor delivery sender: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0563.** From a payment processor alias: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0564.** From a government notices line: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0565.** From an unregistered short code: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0566.** From a verified bank sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0567.** From a personal handset: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0568.** From a bulk marketing gateway: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0569.** From an international number: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0570.** From a retail loyalty programme: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0571.** From a logistics tracking sender: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0572.** From a utility provider: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0573.** From an aggregator route: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0574.** From a two-factor delivery sender: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0575.** From a payment processor alias: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0576.** From a government notices line: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0577.** From an unregistered short code: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0578.** From a verified bank sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0579.** From a personal handset: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0580.** From a bulk marketing gateway: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0581.** From an international number: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0582.** From a retail loyalty programme: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0583.** From a logistics tracking sender: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0584.** From a utility provider: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0585.** From an aggregator route: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0586.** From a two-factor delivery sender: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0587.** From a payment processor alias: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0588.** From a government notices line: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0589.** From an unregistered short code: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0590.** From a verified bank sender: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0591.** From a personal handset: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0592.** From a bulk marketing gateway: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0593.** From an international number: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0594.** From a retail loyalty programme: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0595.** From a logistics tracking sender: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0596.** From a utility provider: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0597.** From an aggregator route: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0598.** From a two-factor delivery sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0599.** From a payment processor alias: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0600.** From a government notices line: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0601.** From an unregistered short code: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0602.** From a verified bank sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0603.** From a personal handset: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0604.** From a bulk marketing gateway: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0605.** From an international number: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0606.** From a retail loyalty programme: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0607.** From a logistics tracking sender: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0608.** From a utility provider: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0609.** From an aggregator route: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0610.** From a two-factor delivery sender: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0611.** From a payment processor alias: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0612.** From a government notices line: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0613.** From an unregistered short code: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0614.** From a verified bank sender: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0615.** From a personal handset: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0616.** From a bulk marketing gateway: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0617.** From an international number: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0618.** From a retail loyalty programme: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0619.** From a logistics tracking sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0620.** From a utility provider: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0621.** From an aggregator route: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0622.** From a two-factor delivery sender: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0623.** From a payment processor alias: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0624.** From a government notices line: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0625.** From an unregistered short code: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0626.** From a verified bank sender: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0627.** From a personal handset: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0628.** From a bulk marketing gateway: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0629.** From an international number: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0630.** From a retail loyalty programme: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0631.** From a logistics tracking sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0632.** From a utility provider: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0633.** From an aggregator route: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0634.** From a two-factor delivery sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0635.** From a payment processor alias: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0636.** From a government notices line: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0637.** From an unregistered short code: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0638.** From a verified bank sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0639.** From a personal handset: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0640.** From a bulk marketing gateway: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0641.** From an international number: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0642.** From a retail loyalty programme: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0643.** From a logistics tracking sender: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0644.** From a utility provider: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0645.** From an aggregator route: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0646.** From a two-factor delivery sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0647.** From a payment processor alias: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0648.** From a government notices line: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0649.** From an unregistered short code: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0650.** From a verified bank sender: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0651.** From a personal handset: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0652.** From a bulk marketing gateway: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0653.** From an international number: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0654.** From a retail loyalty programme: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0655.** From a logistics tracking sender: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0656.** From a utility provider: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0657.** From an aggregator route: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0658.** From a two-factor delivery sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0659.** From a payment processor alias: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0660.** From a government notices line: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0661.** From an unregistered short code: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0662.** From a verified bank sender: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0663.** From a personal handset: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0664.** From a bulk marketing gateway: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0665.** From an international number: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0666.** From a retail loyalty programme: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0667.** From a logistics tracking sender: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0668.** From a utility provider: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0669.** From an aggregator route: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0670.** From a two-factor delivery sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0671.** From a payment processor alias: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0672.** From a government notices line: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0673.** From an unregistered short code: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0674.** From a verified bank sender: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0675.** From a personal handset: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0676.** From a bulk marketing gateway: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0677.** From an international number: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0678.** From a retail loyalty programme: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0679.** From a logistics tracking sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0680.** From a utility provider: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0681.** From an aggregator route: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0682.** From a two-factor delivery sender: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0683.** From a payment processor alias: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0684.** From a government notices line: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0685.** From an unregistered short code: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0686.** From a verified bank sender: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0687.** From a personal handset: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0688.** From a bulk marketing gateway: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0689.** From an international number: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0690.** From a retail loyalty programme: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0691.** From a logistics tracking sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0692.** From a utility provider: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0693.** From an aggregator route: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0694.** From a two-factor delivery sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0695.** From a payment processor alias: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0696.** From a government notices line: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0697.** From an unregistered short code: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0698.** From a verified bank sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0699.** From a personal handset: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0700.** From a bulk marketing gateway: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0701.** From an international number: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0702.** From a retail loyalty programme: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0703.** From a logistics tracking sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0704.** From a utility provider: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0705.** From an aggregator route: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0706.** From a two-factor delivery sender: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0707.** From a payment processor alias: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0708.** From a government notices line: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0709.** From an unregistered short code: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0710.** From a verified bank sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0711.** From a personal handset: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0712.** From a bulk marketing gateway: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0713.** From an international number: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0714.** From a retail loyalty programme: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0715.** From a logistics tracking sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0716.** From a utility provider: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0717.** From an aggregator route: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0718.** From a two-factor delivery sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0719.** From a payment processor alias: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0720.** From a government notices line: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0721.** From an unregistered short code: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0722.** From a verified bank sender: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0723.** From a personal handset: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0724.** From a bulk marketing gateway: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0725.** From an international number: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0726.** From a retail loyalty programme: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0727.** From a logistics tracking sender: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0728.** From a utility provider: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0729.** From an aggregator route: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0730.** From a two-factor delivery sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0731.** From a payment processor alias: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0732.** From a government notices line: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0733.** From an unregistered short code: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0734.** From a verified bank sender: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0735.** From a personal handset: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0736.** From a bulk marketing gateway: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0737.** From an international number: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0738.** From a retail loyalty programme: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0739.** From a logistics tracking sender: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0740.** From a utility provider: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0741.** From an aggregator route: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0742.** From a two-factor delivery sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0743.** From a payment processor alias: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0744.** From a government notices line: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0745.** From an unregistered short code: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0746.** From a verified bank sender: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0747.** From a personal handset: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0748.** From a bulk marketing gateway: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0749.** From an international number: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0750.** From a retail loyalty programme: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0751.** From a logistics tracking sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0752.** From a utility provider: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0753.** From an aggregator route: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0754.** From a two-factor delivery sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0755.** From a payment processor alias: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0756.** From a government notices line: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0757.** From an unregistered short code: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0758.** From a verified bank sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0759.** From a personal handset: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0760.** From a bulk marketing gateway: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0761.** From an international number: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0762.** From a retail loyalty programme: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0763.** From a logistics tracking sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0764.** From a utility provider: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0765.** From an aggregator route: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0766.** From a two-factor delivery sender: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0767.** From a payment processor alias: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0768.** From a government notices line: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0769.** From an unregistered short code: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0770.** From a verified bank sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0771.** From a personal handset: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0772.** From a bulk marketing gateway: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0773.** From an international number: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0774.** From a retail loyalty programme: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0775.** From a logistics tracking sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0776.** From a utility provider: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0777.** From an aggregator route: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0778.** From a two-factor delivery sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0779.** From a payment processor alias: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0780.** From a government notices line: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0781.** From an unregistered short code: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0782.** From a verified bank sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0783.** From a personal handset: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0784.** From a bulk marketing gateway: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0785.** From an international number: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0786.** From a retail loyalty programme: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0787.** From a logistics tracking sender: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0788.** From a utility provider: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0789.** From an aggregator route: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0790.** From a two-factor delivery sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0791.** From a payment processor alias: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0792.** From a government notices line: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0793.** From an unregistered short code: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0794.** From a verified bank sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0795.** From a personal handset: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0796.** From a bulk marketing gateway: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0797.** From an international number: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0798.** From a retail loyalty programme: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0799.** From a logistics tracking sender: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0800.** From a utility provider: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0801.** From an aggregator route: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0802.** From a two-factor delivery sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0803.** From a payment processor alias: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0804.** From a government notices line: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0805.** From an unregistered short code: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0806.** From a verified bank sender: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0807.** From a personal handset: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0808.** From a bulk marketing gateway: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0809.** From an international number: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0810.** From a retail loyalty programme: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0811.** From a logistics tracking sender: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0812.** From a utility provider: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0813.** From an aggregator route: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0814.** From a two-factor delivery sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0815.** From a payment processor alias: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0816.** From a government notices line: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0817.** From an unregistered short code: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0818.** From a verified bank sender: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0819.** From a personal handset: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0820.** From a bulk marketing gateway: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0821.** From an international number: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0822.** From a retail loyalty programme: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0823.** From a logistics tracking sender: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0824.** From a utility provider: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0825.** From an aggregator route: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0826.** From a two-factor delivery sender: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0827.** From a payment processor alias: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0828.** From a government notices line: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0829.** From an unregistered short code: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0830.** From a verified bank sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0831.** From a personal handset: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0832.** From a bulk marketing gateway: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0833.** From an international number: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0834.** From a retail loyalty programme: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0835.** From a logistics tracking sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0836.** From a utility provider: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0837.** From an aggregator route: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0838.** From a two-factor delivery sender: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0839.** From a payment processor alias: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0840.** From a government notices line: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0841.** From an unregistered short code: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0842.** From a verified bank sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0843.** From a personal handset: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0844.** From a bulk marketing gateway: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0845.** From an international number: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0846.** From a retail loyalty programme: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0847.** From a logistics tracking sender: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0848.** From a utility provider: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0849.** From an aggregator route: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0850.** From a two-factor delivery sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0851.** From a payment processor alias: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0852.** From a government notices line: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0853.** From an unregistered short code: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0854.** From a verified bank sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0855.** From a personal handset: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0856.** From a bulk marketing gateway: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0857.** From an international number: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0858.** From a retail loyalty programme: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0859.** From a logistics tracking sender: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0860.** From a utility provider: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0861.** From an aggregator route: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0862.** From a two-factor delivery sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0863.** From a payment processor alias: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0864.** From a government notices line: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0865.** From an unregistered short code: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0866.** From a verified bank sender: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0867.** From a personal handset: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0868.** From a bulk marketing gateway: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0869.** From an international number: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0870.** From a retail loyalty programme: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0871.** From a logistics tracking sender: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0872.** From a utility provider: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0873.** From an aggregator route: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0874.** From a two-factor delivery sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0875.** From a payment processor alias: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0876.** From a government notices line: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0877.** From an unregistered short code: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0878.** From a verified bank sender: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0879.** From a personal handset: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0880.** From a bulk marketing gateway: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0881.** From an international number: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0882.** From a retail loyalty programme: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0883.** From a logistics tracking sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0884.** From a utility provider: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0885.** From an aggregator route: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0886.** From a two-factor delivery sender: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0887.** From a payment processor alias: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0888.** From a government notices line: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0889.** From an unregistered short code: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0890.** From a verified bank sender: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0891.** From a personal handset: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0892.** From a bulk marketing gateway: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0893.** From an international number: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0894.** From a retail loyalty programme: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0895.** From a logistics tracking sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0896.** From a utility provider: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0897.** From an aggregator route: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0898.** From a two-factor delivery sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0899.** From a payment processor alias: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0900.** From a government notices line: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0901.** From an unregistered short code: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0902.** From a verified bank sender: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0903.** From a personal handset: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0904.** From a bulk marketing gateway: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0905.** From an international number: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0906.** From a retail loyalty programme: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0907.** From a logistics tracking sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0908.** From a utility provider: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0909.** From an aggregator route: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0910.** From a two-factor delivery sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0911.** From a payment processor alias: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0912.** From a government notices line: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0913.** From an unregistered short code: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0914.** From a verified bank sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0915.** From a personal handset: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0916.** From a bulk marketing gateway: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0917.** From an international number: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0918.** From a retail loyalty programme: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0919.** From a logistics tracking sender: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0920.** From a utility provider: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0921.** From an aggregator route: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0922.** From a two-factor delivery sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0923.** From a payment processor alias: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0924.** From a government notices line: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0925.** From an unregistered short code: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0926.** From a verified bank sender: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0927.** From a personal handset: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0928.** From a bulk marketing gateway: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0929.** From an international number: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0930.** From a retail loyalty programme: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0931.** From a logistics tracking sender: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0932.** From a utility provider: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0933.** From an aggregator route: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0934.** From a two-factor delivery sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0935.** From a payment processor alias: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0936.** From a government notices line: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0937.** From an unregistered short code: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0938.** From a verified bank sender: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0939.** From a personal handset: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0940.** From a bulk marketing gateway: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0941.** From an international number: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0942.** From a retail loyalty programme: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0943.** From a logistics tracking sender: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0944.** From a utility provider: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0945.** From an aggregator route: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0946.** From a two-factor delivery sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0947.** From a payment processor alias: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0948.** From a government notices line: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0949.** From an unregistered short code: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0950.** From a verified bank sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0951.** From a personal handset: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0952.** From a bulk marketing gateway: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0953.** From an international number: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0954.** From a retail loyalty programme: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0955.** From a logistics tracking sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0956.** From a utility provider: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0957.** From an aggregator route: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0958.** From a two-factor delivery sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0959.** From a payment processor alias: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0960.** From a government notices line: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0961.** From an unregistered short code: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0962.** From a verified bank sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0963.** From a personal handset: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0964.** From a bulk marketing gateway: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0965.** From an international number: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0966.** From a retail loyalty programme: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0967.** From a logistics tracking sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0968.** From a utility provider: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0969.** From an aggregator route: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0970.** From a two-factor delivery sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0971.** From a payment processor alias: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0972.** From a government notices line: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0973.** From an unregistered short code: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0974.** From a verified bank sender: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0975.** From a personal handset: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0976.** From a bulk marketing gateway: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0977.** From an international number: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0978.** From a retail loyalty programme: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0979.** From a logistics tracking sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0980.** From a utility provider: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0981.** From an aggregator route: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0982.** From a two-factor delivery sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-0983.** From a payment processor alias: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0984.** From a government notices line: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0985.** From an unregistered short code: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0986.** From a verified bank sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0987.** From a personal handset: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0988.** From a bulk marketing gateway: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0989.** From an international number: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0990.** From a retail loyalty programme: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0991.** From a logistics tracking sender: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0992.** From a utility provider: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-0993.** From an aggregator route: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-0994.** From a two-factor delivery sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-0995.** From a payment processor alias: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-0996.** From a government notices line: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-0997.** From an unregistered short code: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-0998.** From a verified bank sender: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-0999.** From a personal handset: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1000.** From a bulk marketing gateway: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1001.** From an international number: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1002.** From a retail loyalty programme: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1003.** From a logistics tracking sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1004.** From a utility provider: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1005.** From an aggregator route: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1006.** From a two-factor delivery sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1007.** From a payment processor alias: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1008.** From a government notices line: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1009.** From an unregistered short code: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1010.** From a verified bank sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1011.** From a personal handset: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1012.** From a bulk marketing gateway: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1013.** From an international number: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1014.** From a retail loyalty programme: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1015.** From a logistics tracking sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1016.** From a utility provider: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1017.** From an aggregator route: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1018.** From a two-factor delivery sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1019.** From a payment processor alias: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1020.** From a government notices line: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1021.** From an unregistered short code: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1022.** From a verified bank sender: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1023.** From a personal handset: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1024.** From a bulk marketing gateway: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1025.** From an international number: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1026.** From a retail loyalty programme: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1027.** From a logistics tracking sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1028.** From a utility provider: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1029.** From an aggregator route: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1030.** From a two-factor delivery sender: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1031.** From a payment processor alias: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1032.** From a government notices line: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1033.** From an unregistered short code: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1034.** From a verified bank sender: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1035.** From a personal handset: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1036.** From a bulk marketing gateway: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1037.** From an international number: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1038.** From a retail loyalty programme: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1039.** From a logistics tracking sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1040.** From a utility provider: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1041.** From an aggregator route: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1042.** From a two-factor delivery sender: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1043.** From a payment processor alias: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1044.** From a government notices line: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1045.** From an unregistered short code: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1046.** From a verified bank sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1047.** From a personal handset: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1048.** From a bulk marketing gateway: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1049.** From an international number: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1050.** From a retail loyalty programme: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1051.** From a logistics tracking sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1052.** From a utility provider: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1053.** From an aggregator route: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1054.** From a two-factor delivery sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1055.** From a payment processor alias: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1056.** From a government notices line: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1057.** From an unregistered short code: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1058.** From a verified bank sender: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1059.** From a personal handset: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1060.** From a bulk marketing gateway: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1061.** From an international number: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1062.** From a retail loyalty programme: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1063.** From a logistics tracking sender: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1064.** From a utility provider: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1065.** From an aggregator route: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1066.** From a two-factor delivery sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1067.** From a payment processor alias: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1068.** From a government notices line: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1069.** From an unregistered short code: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1070.** From a verified bank sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1071.** From a personal handset: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1072.** From a bulk marketing gateway: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1073.** From an international number: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1074.** From a retail loyalty programme: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1075.** From a logistics tracking sender: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1076.** From a utility provider: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1077.** From an aggregator route: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1078.** From a two-factor delivery sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1079.** From a payment processor alias: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1080.** From a government notices line: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1081.** From an unregistered short code: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1082.** From a verified bank sender: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1083.** From a personal handset: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1084.** From a bulk marketing gateway: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1085.** From an international number: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1086.** From a retail loyalty programme: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1087.** From a logistics tracking sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1088.** From a utility provider: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1089.** From an aggregator route: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1090.** From a two-factor delivery sender: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1091.** From a payment processor alias: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1092.** From a government notices line: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1093.** From an unregistered short code: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1094.** From a verified bank sender: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1095.** From a personal handset: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1096.** From a bulk marketing gateway: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1097.** From an international number: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1098.** From a retail loyalty programme: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1099.** From a logistics tracking sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1100.** From a utility provider: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1101.** From an aggregator route: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1102.** From a two-factor delivery sender: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1103.** From a payment processor alias: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1104.** From a government notices line: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1105.** From an unregistered short code: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1106.** From a verified bank sender: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1107.** From a personal handset: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1108.** From a bulk marketing gateway: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1109.** From an international number: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1110.** From a retail loyalty programme: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1111.** From a logistics tracking sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1112.** From a utility provider: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1113.** From an aggregator route: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1114.** From a two-factor delivery sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1115.** From a payment processor alias: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1116.** From a government notices line: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1117.** From an unregistered short code: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1118.** From a verified bank sender: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1119.** From a personal handset: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1120.** From a bulk marketing gateway: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1121.** From an international number: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1122.** From a retail loyalty programme: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1123.** From a logistics tracking sender: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1124.** From a utility provider: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1125.** From an aggregator route: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1126.** From a two-factor delivery sender: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1127.** From a payment processor alias: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1128.** From a government notices line: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1129.** From an unregistered short code: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1130.** From a verified bank sender: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1131.** From a personal handset: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1132.** From a bulk marketing gateway: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1133.** From an international number: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1134.** From a retail loyalty programme: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1135.** From a logistics tracking sender: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1136.** From a utility provider: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1137.** From an aggregator route: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1138.** From a two-factor delivery sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1139.** From a payment processor alias: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1140.** From a government notices line: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1141.** From an unregistered short code: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1142.** From a verified bank sender: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1143.** From a personal handset: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1144.** From a bulk marketing gateway: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1145.** From an international number: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1146.** From a retail loyalty programme: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1147.** From a logistics tracking sender: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1148.** From a utility provider: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1149.** From an aggregator route: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1150.** From a two-factor delivery sender: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1151.** From a payment processor alias: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1152.** From a government notices line: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1153.** From an unregistered short code: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1154.** From a verified bank sender: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1155.** From a personal handset: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1156.** From a bulk marketing gateway: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1157.** From an international number: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1158.** From a retail loyalty programme: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1159.** From a logistics tracking sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1160.** From a utility provider: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1161.** From an aggregator route: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1162.** From a two-factor delivery sender: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1163.** From a payment processor alias: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1164.** From a government notices line: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1165.** From an unregistered short code: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1166.** From a verified bank sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1167.** From a personal handset: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1168.** From a bulk marketing gateway: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1169.** From an international number: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1170.** From a retail loyalty programme: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1171.** From a logistics tracking sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1172.** From a utility provider: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1173.** From an aggregator route: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1174.** From a two-factor delivery sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1175.** From a payment processor alias: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1176.** From a government notices line: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1177.** From an unregistered short code: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1178.** From a verified bank sender: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1179.** From a personal handset: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1180.** From a bulk marketing gateway: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1181.** From an international number: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1182.** From a retail loyalty programme: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1183.** From a logistics tracking sender: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1184.** From a utility provider: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1185.** From an aggregator route: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1186.** From a two-factor delivery sender: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1187.** From a payment processor alias: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1188.** From a government notices line: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1189.** From an unregistered short code: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1190.** From a verified bank sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1191.** From a personal handset: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1192.** From a bulk marketing gateway: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1193.** From an international number: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1194.** From a retail loyalty programme: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1195.** From a logistics tracking sender: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1196.** From a utility provider: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1197.** From an aggregator route: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1198.** From a two-factor delivery sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1199.** From a payment processor alias: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1200.** From a government notices line: "let us study at the library after the exam". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1201.** From an unregistered short code: "bargain bundle of accessories, retail closeout". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1202.** From a verified bank sender: "authorize the mandate on the account". Gold label `spam`. Distinct high-risk tokens: `mandate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1203.** From a personal handset: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1204.** From a bulk marketing gateway: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1205.** From an international number: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1206.** From a retail loyalty programme: "walking the dog before the rain starts". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1207.** From a logistics tracking sender: "exclusive member discount on the fashion collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1208.** From a utility provider: "security check on the card holder record". Gold label `spam`. Distinct high-risk tokens: `kyc` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1209.** From an aggregator route: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1210.** From a two-factor delivery sender: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1211.** From a payment processor alias: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1212.** From a government notices line: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1213.** From an unregistered short code: "are we still meeting for dinner tomorrow". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1214.** From a verified bank sender: "midseason sale, up to fifty percent off the catalog". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1215.** From a personal handset: "confirm the passcode to finish signing in". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1216.** From a bulk marketing gateway: "mandatory compliance action, forfeit and chargeback recorded". Gold label `ham`. Distinct high-risk tokens: `forfeit`, `chargeback` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1217.** From an international number: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1218.** From a retail loyalty programme: "renewal ticket issued, credited to the account". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: `renewal`, `credited` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1219.** From a logistics tracking sender: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1220.** From a utility provider: "the class moved to the second floor room". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1221.** From an aggregator route: "restock alert on the outlet collection". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1222.** From a two-factor delivery sender: "your account will be suspended without action". Gold label `spam`. Distinct high-risk tokens: `suspended` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1223.** From a payment processor alias: "arrest warrant issued, the payid and upi records are suspended". Gold label `spam`. Distinct high-risk tokens: `payid`, `upi` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1224.** From a government notices line: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1225.** From an unregistered short code: "checkin window for the reservation is open". Gold label `spam`. Distinct high-risk tokens: `unlock` (h=1). Distinct safe-harbour tokens: `checkin`, `reservation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1226.** From a verified bank sender: "call me when you finish work". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1227.** From a personal handset: "loyalty members get an extra bundle this season". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1228.** From a bulk marketing gateway: "validate the identity on file for this profile". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1229.** From an international number: "final demand before enforcement, verify and claim the payout". Gold label `ham`. Distinct high-risk tokens: `verify`, `claim`, `payout` (h=3). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1230.** From a retail loyalty programme: "court summons, the payout and seizure are on the invoice". Gold label `ham`. Distinct high-risk tokens: `payout`, `seizure` (h=2). Distinct safe-harbour tokens: `invoice` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1231.** From a logistics tracking sender: "your parcel dispatch reference is attached to the receipt". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: `dispatch`, `receipt` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1232.** From a utility provider: "seasonal claims on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `claims` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

**Case EX-1233.** From an aggregator route: "happy birthday, hope the trip is going well". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1234.** From a two-factor delivery sender: "clearance markdown on last year style". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1235.** From a payment processor alias: "the transfer needs the routing detail on record". Gold label `spam`. Distinct high-risk tokens: `routing` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1236.** From a government notices line: "court warrant pending, unlock the account and confirm the iban". Gold label `spam`. Distinct high-risk tokens: `unlock`, `iban` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1237.** From an unregistered short code: "penalty pending, confirm the otp and the upi on the booking". Gold label `spam`. Distinct high-risk tokens: `otp`, `upi` (h=2). Distinct safe-harbour tokens: `booking` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1238.** From a verified bank sender: "appointment confirmation for the branch counter". Gold label `spam`. Distinct high-risk tokens: `verify` (h=1). Distinct safe-harbour tokens: `appointment`, `confirmation` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1239.** From a personal handset: "running late from the market, start without me". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1240.** From a bulk marketing gateway: "flash promotion on the wholesale range". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1241.** From an international number: "reactivate the dormant customer profile". Gold label `spam`. Distinct high-risk tokens: `reactivate` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1242.** From a retail loyalty programme: "penalty notice, seizure of funds unless the sortcode is provided". Gold label `ham`. Distinct high-risk tokens: `seizure`, `sortcode` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1243.** From a logistics tracking sender: "enforcement notice, verify the iban against the receipt". Gold label `ham`. Distinct high-risk tokens: `verify`, `iban` (h=2). Distinct safe-harbour tokens: `receipt` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1244.** From a utility provider: "the refund against the invoice has been processed". Gold label `spam`. Distinct high-risk tokens: `payout` (h=1). Distinct safe-harbour tokens: `refund`, `invoice` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1245.** From an aggregator route: "the otp was sent, resend the otp again, otp pending". Gold label `spam`. Distinct high-risk tokens: `otp` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. The token `otp` occurs three times but is one distinct entry, so h is 1 and clause 1 does not fire.

**Case EX-1246.** From a two-factor delivery sender: "the game is rained out, movie at home instead". Gold label `ham`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 5 fires, disposition `allow`. Ordinary personal traffic with no register tokens, so the first four clauses do not match.

**Case EX-1247.** From a payment processor alias: "preorder the new product line and save". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. Unsolicited promotional content with no high-risk token. Commercial vocabulary does not contribute to h.

**Case EX-1248.** From a government notices line: "the session will expire shortly". Gold label `spam`. Distinct high-risk tokens: `expire` (h=1). Distinct safe-harbour tokens: none (s=0). Clause 3 fires, disposition `quarantine`. A single unexplained risk signal with no transactional context is the ambiguous band and goes to human review.

**Case EX-1249.** From an unregistered short code: "prosecution deadline, the prize and the lottery entry lapse". Gold label `spam`. Distinct high-risk tokens: `prize`, `lottery` (h=2). Distinct safe-harbour tokens: none (s=0). Clause 1 fires, disposition `block`. Two or more distinct high-risk tokens with no safe-harbour token. Clause 1 fires ahead of every other clause and applies whatever the gold label is.

**Case EX-1250.** From a verified bank sender: "final demand, claim and unlock before the dispatch window". Gold label `spam`. Distinct high-risk tokens: `claim`, `unlock` (h=2). Distinct safe-harbour tokens: `dispatch` (s=1). Clause 1 fires, disposition `block`. Two distinct risk tokens are present, so clause 1 fires before the safe-harbour test is ever reached. The safe-harbour token does not rescue a multi-signal message.

**Case EX-1251.** From a personal handset: "boarding itinerary for the booking on file". Gold label `spam`. Distinct high-risk tokens: `urgent` (h=1). Distinct safe-harbour tokens: `boarding`, `itinerary` (s=2). Clause 2 fires, disposition `allow`. A safe-harbour token accompanies the risk signal, so the message is released even though the gold label is spam.

**Case EX-1252.** From a bulk marketing gateway: "seasonal winners on the retail bundle". Gold label `spam`. Distinct high-risk tokens: none (h=0). Distinct safe-harbour tokens: none (s=0). Clause 4 fires, disposition `block`. The token `winners` is not a register entry; whole-token equality under Section 6 finds no high-risk token, so h is 0.

## 14. Implementation and Review FAQ

**Q. Are `ham` and `spam` valid dispositions?**

No. They are inputs. Only `allow`, `quarantine`, and `block` may be emitted.

**Q. Is Appendix H the register I should implement against?**

No. Appendix H is the base register as adopted at version 3.0. Replay the Section 8 amendment stream under the rules stated there to obtain the effective register at the revision you are computing for.

**Q. A spam message repeats one high-risk token four times. What is h?**

One. Both counts are of distinct register entries, never occurrences, so clause 1 does not fire on repetition.

**Q. A ham message carries two distinct high-risk tokens and no safe-harbour token. What happens?**

Clause 1 fires and the disposition is `block`. Clause 1 is not conditioned on the gold label.

**Q. A spam message carries one high-risk token and one safe-harbour token.**

Clause 2 fires and the disposition is `allow`.

**Q. A message carries two distinct high-risk tokens and a safe-harbour token.**

Clause 1 fires and the disposition is `block`. The safe-harbour exemption applies only when h is exactly 1.

**Q. Does a commercial token from Appendix G raise h?**

No. The commercial register never contributes to h or s.

**Q. Does the token `claims` match the register entry `claim`?**

No. Matching is exact whole-token equality.

**Q. What if I evaluate clause 2 before clause 1?**

You will allow messages that the policy blocks. The clause order in Section 5 is normative.

**Q. A token was added by one amendment and removed by a later one.**

The later amendment governs; the token is absent from the effective register.

**Q. What should a training run record?**

The derived disposition for every corpus row, plus the class balance and a held-out evaluation of the fitted model.

**Q. Does message casing affect matching?**

No. Normalization lower-cases before splitting and matching.

**Q. Are the legacy severity codes still used?**

No, they are superseded per Appendix I.

## 15. Change Log

- **2020-01-01** (A. Okonkwo): Replaced any-match escalation with the ordered cascade in Section 5. Reference change-set CS-100.
- **2020-04-12** (M. Halvorsen): Introduced the safe-harbour register and clause 2 after a passcode suppression incident. Reference change-set CS-101.
- **2020-07-23** (P. Ramaswamy): Clarified that both counts are over distinct register entries. Reference change-set CS-102.
- **2020-10-07** (L. Chen): Recorded that the appendices are frozen at version 3.0 and amended only via Section 8. Reference change-set CS-103.
- **2020-01-18** (S. Adebayo): Reaffirmed that clause 1 applies irrespective of gold label. Reference change-set CS-104.
- **2020-04-02** (R. Fitzgerald): Separated the commercial register so it cannot be mistaken for an escalation trigger. Reference change-set CS-105.
- **2021-07-13** (A. Okonkwo): Fixed matching to whole-token equality after a substring defect. Reference change-set CS-106.
- **2021-10-24** (M. Halvorsen): Rejected a proposal to collapse the taxonomy to allow-or-block. Reference change-set CS-107.
- **2021-01-08** (P. Ramaswamy): Added financial abbreviations to the high-risk register following account-takeover trends. Reference change-set CS-108.
- **2021-04-19** (L. Chen): Added the adjudicated example bank to calibrate reviewers. Reference change-set CS-109.
- **2021-07-03** (S. Adebayo): Replaced any-match escalation with the ordered cascade in Section 5. Reference change-set CS-110.
- **2021-10-14** (R. Fitzgerald): Introduced the safe-harbour register and clause 2 after a passcode suppression incident. Reference change-set CS-111.
- **2022-01-25** (A. Okonkwo): Clarified that both counts are over distinct register entries. Reference change-set CS-112.
- **2022-04-09** (M. Halvorsen): Recorded that the appendices are frozen at version 3.0 and amended only via Section 8. Reference change-set CS-113.
- **2022-07-20** (P. Ramaswamy): Reaffirmed that clause 1 applies irrespective of gold label. Reference change-set CS-114.
- **2022-10-04** (L. Chen): Separated the commercial register so it cannot be mistaken for an escalation trigger. Reference change-set CS-115.
- **2022-01-15** (S. Adebayo): Fixed matching to whole-token equality after a substring defect. Reference change-set CS-116.
- **2022-04-26** (R. Fitzgerald): Rejected a proposal to collapse the taxonomy to allow-or-block. Reference change-set CS-117.
- **2023-07-10** (A. Okonkwo): Added financial abbreviations to the high-risk register following account-takeover trends. Reference change-set CS-118.
- **2023-10-21** (M. Halvorsen): Added the adjudicated example bank to calibrate reviewers. Reference change-set CS-119.
- **2023-01-05** (P. Ramaswamy): Replaced any-match escalation with the ordered cascade in Section 5. Reference change-set CS-120.
- **2023-04-16** (L. Chen): Introduced the safe-harbour register and clause 2 after a passcode suppression incident. Reference change-set CS-121.
- **2023-07-27** (S. Adebayo): Clarified that both counts are over distinct register entries. Reference change-set CS-122.
- **2023-10-11** (R. Fitzgerald): Recorded that the appendices are frozen at version 3.0 and amended only via Section 8. Reference change-set CS-123.
- **2024-01-22** (A. Okonkwo): Reaffirmed that clause 1 applies irrespective of gold label. Reference change-set CS-124.
- **2024-04-06** (M. Halvorsen): Separated the commercial register so it cannot be mistaken for an escalation trigger. Reference change-set CS-125.
- **2024-07-17** (P. Ramaswamy): Fixed matching to whole-token equality after a substring defect. Reference change-set CS-126.
- **2024-10-01** (L. Chen): Rejected a proposal to collapse the taxonomy to allow-or-block. Reference change-set CS-127.
- **2024-01-12** (S. Adebayo): Added financial abbreviations to the high-risk register following account-takeover trends. Reference change-set CS-128.
- **2024-04-23** (R. Fitzgerald): Added the adjudicated example bank to calibrate reviewers. Reference change-set CS-129.
- **2025-07-07** (A. Okonkwo): Replaced any-match escalation with the ordered cascade in Section 5. Reference change-set CS-130.
- **2025-10-18** (M. Halvorsen): Introduced the safe-harbour register and clause 2 after a passcode suppression incident. Reference change-set CS-131.
- **2025-01-02** (P. Ramaswamy): Clarified that both counts are over distinct register entries. Reference change-set CS-132.
- **2025-04-13** (L. Chen): Recorded that the appendices are frozen at version 3.0 and amended only via Section 8. Reference change-set CS-133.
- **2025-07-24** (S. Adebayo): Reaffirmed that clause 1 applies irrespective of gold label. Reference change-set CS-134.
- **2025-10-08** (R. Fitzgerald): Separated the commercial register so it cannot be mistaken for an escalation trigger. Reference change-set CS-135.
- **2026-01-19** (A. Okonkwo): Fixed matching to whole-token equality after a substring defect. Reference change-set CS-136.
- **2026-04-03** (M. Halvorsen): Rejected a proposal to collapse the taxonomy to allow-or-block. Reference change-set CS-137.
- **2026-07-14** (P. Ramaswamy): Added financial abbreviations to the high-risk register following account-takeover trends. Reference change-set CS-138.
- **2026-10-25** (L. Chen): Added the adjudicated example bank to calibrate reviewers. Reference change-set CS-139.

## 16. Model Exchange Format

Classifiers trained against this policy move from the training tier to the serving tier as a single file in the TLM1 container format. Serving nodes reject a file that does not conform.

All integers are unsigned and little-endian. Strings are unpadded ASCII. There is no alignment padding anywhere in the file.

The header occupies the first twenty bytes.

| Offset | Type | Field |
|---|---|---|
| 0 | 4 bytes | magic, the ASCII characters `TLM1` |
| 4 | uint16 | container version, currently 3 |
| 6 | uint16 | class count `C` |
| 8 | uint32 | vocabulary size `V` |
| 12 | uint64 | `N`, the number of training documents |

The class table follows immediately: `C` records, ordered by ascending byte value of the class name.

| Type | Field |
|---|---|
| uint8 | length of the class name in bytes |
| bytes | class name |
| uint64 | number of training documents carrying this class |
| uint64 | total token occurrences across those documents |

The vocabulary table follows the class table: `V` records, ordered by ascending byte value of the token.

| Type | Field |
|---|---|
| uint8 | length of the token in bytes |
| bytes | token |
| uint64 repeated `C` times | occurrences of this token in each class, in class-table order |

The file ends with a four-byte trailer holding a uint32 checksum taken over every byte from offset 0 up to the first byte of the trailer. The checksum is FNV-1a, 32 bit: begin with the accumulator at 2166136261, then for each byte exclusive-or that byte into the accumulator and multiply the accumulator by 16777619, truncating to 32 bits after each multiplication.

Counts are stored raw. Probabilities, log probabilities, weights, and smoothing constants are not stored. A serving node applies add-one smoothing at inference time using the per-class token totals and the vocabulary size `V` carried in the file, scoring a message by summing, over the tokens of the message, the log of one plus the token count for the class divided by the class token total plus `V`, added to the log of the class document count divided by `N`.

## Appendix J. Extended Glossary

- **Abuse rate**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Adjudication**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Aggregator**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Allowlist**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Appeal window**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Audit sample**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Base register**: register contents as printed in the appendices, frozen at version 3.0. Measured on held-out traffic during audit.
- **Bulk sender**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Calibration set**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Cascade**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Class balance**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Clause order**: the normative evaluation order of the Section 5 cascade; reordering changes outcomes. Used consistently across this dossier and the annexes.
- **Commercial register**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Controlled vocabulary**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Corpus**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Deceptive intent**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Derivation**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Disposition rate**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Distinct count**: the number of different register entries present in a message, each counted once regardless of repetition; see Section 6. Interpreted per the numbered clauses, which govern over this glossary.
- **Downgrade**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Effective register**: the base register after every Section 8 amendment has been applied in order; the register an implementation must use. Measured on held-out traffic during audit.
- **Escalation path**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Evaluation split**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **False positive**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **False negative**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **First-touch**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Gateway**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Gold field**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Held message**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Holdout**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Ingestion**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Invariant lowercasing**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Jurisdiction**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Label noise**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Macro average**: the unweighted mean of a per-class metric across the three dispositions, used so the minority class is not masked. Interpreted per the numbered clauses, which govern over this glossary.
- **Message unit**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Minimisation**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Normalization**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Occurrence count**: the number of times register entries appear including repeats; explicitly not what the cascade uses. Used consistently across this dossier and the annexes.
- **One-time passcode**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Over-blocking**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Precision**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Priority queue**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Quiet hours**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Recall**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Reference corpus**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Register amendment**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Release**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Retention ceiling**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Reviewer**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Risk model**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Safe harbour**: the register whose presence releases an otherwise escalated message under clause 2. Used consistently across this dossier and the annexes.
- **Sampling**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Sender class**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Service level**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Short code**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Suppression**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Taxonomy**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Token**: an operational term used in this dossier; interpreted per the numbered clauses, which govern over this glossary. Defined operationally for reviewers and implementers.
- **Tokenization**: an operational term used in this dossier; used consistently across this dossier and the annexes. Measured on held-out traffic during audit.
- **Transactional**: an operational term used in this dossier; recorded in the review record where applicable. Interpreted per the numbered clauses, which govern over this glossary.
- **Under-blocking**: an operational term used in this dossier; defined operationally for reviewers and implementers. Used consistently across this dossier and the annexes.
- **Unsolicited**: an operational term used in this dossier; measured on held-out traffic during audit. Recorded in the review record where applicable.
- **Whole-token equality**: exact comparison of a complete normalized token against a register entry, with no substring or stem matching. Interpreted per the numbered clauses, which govern over this glossary.

## Appendix G. Commercial Keyword Register (Informational, Not an Escalation Trigger)

Tracked for commercial reporting and sender analytics. Presence of a commercial token does not change a disposition and does not contribute to `h` or `s`. This register is reproduced so reviewers can recognise ordinary promotional vocabulary and avoid mistaking it for a risk signal.

| # | Token | # | Token | # | Token |
|---|---|---|---|---|---|
| 1 | `offer` | 2 | `discount` | 3 | `sale` |
| 4 | `deal` | 5 | `cheap` | 6 | `buy` |
| 7 | `shipping` | 8 | `limited` | 9 | `stock` |
| 10 | `coupon` | 11 | `promo` | 12 | `save` |
| 13 | `percent` | 14 | `subscribe` | 15 | `newsletter` |
| 16 | `catalog` | 17 | `brand` | 18 | `store` |
| 19 | `shop` | 20 | `gift` | 21 | `bonus` |
| 22 | `points` | 23 | `member` | 24 | `clearance` |
| 25 | `bargain` | 26 | `wholesale` | 27 | `retail` |
| 28 | `package` | 29 | `product` | 30 | `item` |
| 31 | `collection` | 32 | `season` | 33 | `trend` |
| 34 | `style` | 35 | `fashion` | 36 | `warehouse` |
| 37 | `outlet` | 38 | `markdown` | 39 | `closeout` |
| 40 | `liquidation` | 41 | `restock` | 42 | `preorder` |
| 43 | `loyalty` | 44 | `rebate` | 45 | `bundle` |

## Appendix H. High-Risk Register, Base Contents as Adopted at Version 3.0

This is the **base** high-risk register. It is not the effective register. Apply the amendments in Section 8 to obtain the effective register that contributes to `h`.

| # | Token | # | Token | # | Token |
|---|---|---|---|---|---|
| 1 | `prize` | 2 | `winner` | 3 | `urgent` |
| 4 | `claim` | 5 | `verify` | 6 | `suspended` |
| 7 | `congratulations` | 8 | `selected` | 9 | `guaranteed` |
| 10 | `lottery` | 11 | `won` | 12 | `otp` |
| 13 | `kyc` | 14 | `ifsc` | 15 | `giro` |
| 16 | `sortcode` | 17 | `chargeback` | 18 | `overdraft` |
| 19 | `topup` | 20 | `iban` | 21 | `swift` |
| 22 | `bic` | 23 | `routing` | 24 | `cvv` |
| 25 | `ssn` | 26 | `netbanking` | 27 | `upi` |
| 28 | `payee` | 29 | `mandate` | 30 | `payout` |
| 31 | `reactivate` | 32 | `unlock` | 33 | `expire` |
| 34 | `free` | 35 | `refund` | 36 | `cash` |
| 37 | `credited` | 38 | `reward` | 39 | `debited` |

The base register contains 39 tokens. Several entries are ordinary-looking financial abbreviations rather than obviously deceptive words; they are present because they dominate account-takeover and payment-diversion traffic in the platform's incident history.

## Appendix S. Safe-Harbour Register, Base Contents as Adopted at Version 3.0

This is the **base** safe-harbour register. It is not the effective register. Apply the amendments in Section 8 to obtain the effective register that contributes to `s`. Safe-harbour tokens mark genuine transactional context and, under clause 2, release a message that would otherwise be escalated.

| # | Token | # | Token |
|---|---|---|---|
| 1 | `receipt` | 2 | `invoice` |
| 3 | `appointment` | 4 | `booking` |
| 5 | `dispatch` | 6 | `itinerary` |
| 7 | `reservation` | 8 | `renewal` |
| 9 | `enrolment` | 10 | `ticket` |
| 11 | `boarding` | 12 | `tracking` |
| 13 | `notice` |  |  |

The base register contains 13 tokens.

## Appendix I. Superseded Schemes (Do Not Implement)

Retained for traceability only. These must not be implemented and must not be emitted by a conformant pipeline.

- **Legacy binary scheme (deprecated at version 2.0).** A two-valued `safe`/`unsafe` outcome predating the quarantine band.
- **Legacy severity codes S0 through S3 (deprecated at version 2.4).** A four-tier numeric severity applied inconsistently by reviewers.
- **Any-match escalation (deprecated at version 3.0).** An earlier rule that quarantined a spam message on the presence of any single high-risk token, with no safe-harbour test and no distinct-count threshold. It is superseded by the cascade in Section 5 and must not be reintroduced.
- **Gold passthrough (prohibited).** Emitting the corpus gold label directly as a disposition.

Any implementation that emits `safe`, `unsafe`, `S0`, `S1`, `S2`, `S3`, `ham`, or `spam` as a disposition is non-conformant by construction.

